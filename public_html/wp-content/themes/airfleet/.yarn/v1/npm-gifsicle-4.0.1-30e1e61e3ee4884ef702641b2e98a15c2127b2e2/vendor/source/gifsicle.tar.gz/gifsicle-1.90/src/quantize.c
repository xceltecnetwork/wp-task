/* quantize.c - Histograms and quantization for gifsicle.
   Copyright (C) 1997-2017 Eddie Kohler, ekohler@gmail.com
   This file is part of gifsicle.

   Gifsicle is free software. It is distributed under the GNU Public License,
   version 2; you can copy, distribute, or alter it at will, as long
   as this notice is kept intact and this source code is made available. There
   is no warranty, express or implied. */

#include <config.h>
#include "gifsicle.h"
#include "kcolor.h"
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <ctype.h>
#include <math.h>

/* Invariant: (0<=x<256) ==> (srgb_revgamma[srgb_gamma[x] >> 7] <= x). */

static const uint16_t srgb_gamma_table_256[256] = {
    0, 10, 20, 30, 40, 50, 60, 70,
    80, 90, 99, 110, 120, 132, 144, 157,
    170, 184, 198, 213, 229, 246, 263, 281,
    299, 319, 338, 359, 380, 403, 425, 449,
    473, 498, 524, 551, 578, 606, 635, 665,
    695, 727, 759, 792, 825, 860, 895, 931,
    968, 1006, 1045, 1085, 1125, 1167, 1209, 1252,
    1296, 1341, 1386, 1433, 1481, 1529, 1578, 1629,
    1680, 1732, 1785, 1839, 1894, 1950, 2007, 2065,
    2123, 2183, 2244, 2305, 2368, 2432, 2496, 2562,
    2629, 2696, 2765, 2834, 2905, 2977, 3049, 3123,
    3198, 3273, 3350, 3428, 3507, 3587, 3668, 3750,
    3833, 3917, 4002, 4088, 4176, 4264, 4354, 4444,
    4536, 4629, 4723, 4818, 4914, 5011, 5109, 5209,
    5309, 5411, 5514, 5618, 5723, 5829, 5936, 6045,
    6154, 6265, 6377, 6490, 6604, 6720, 6836, 6954,
    7073, 7193, 7315, 7437, 7561, 7686, 7812, 7939,
    8067, 8197, 8328, 8460, 8593, 8728, 8863, 9000,
    9139, 9278, 9419, 9560, 9704, 9848, 9994, 10140,
    10288, 10438, 10588, 10740, 10893, 11048, 11204, 11360,
    11519, 11678, 11839, 12001, 12164, 12329, 12495, 12662,
    12831, 13000, 13172, 13344, 13518, 13693, 13869, 14047,
    14226, 14406, 14588, 14771, 14955, 15141, 15328, 15516,
    15706, 15897, 16089, 16283, 16478, 16675, 16872, 17071,
    17272, 17474, 17677, 17882, 18088, 18295, 18504, 18714,
    18926, 19138, 19353, 19569, 19786, 20004, 20224, 20445,
    20668, 20892, 21118, 21345, 21573, 21803, 22034, 22267,
    22501, 22736, 22973, 23211, 23451, 23692, 23935, 24179,
    24425, 24672, 24920, 25170, 25421, 25674, 25928, 26184,
    26441, 26700, 26960, 27222, 27485, 27749, 28016, 28283,
    28552, 28823, 29095, 29368, 29643, 29920, 30197, 30477,
    30758, 31040, 31324, 31610, 31897, 32185, 32475, 32767
};

static const uint16_t srgb_revgamma_table_256[256] = {
    0, 1628, 2776, 3619, 4309, 4904, 5434, 5914,
    6355, 6765, 7150, 7513, 7856, 8184, 8497, 8798,
    9086, 9365, 9634, 9895, 10147, 10393, 10631, 10864,
    11091, 11312, 11528, 11739, 11946, 12148, 12347, 12541,
    12732, 12920, 13104, 13285, 13463, 13639, 13811, 13981,
    14149, 14314, 14476, 14637, 14795, 14951, 15105, 15257,
    15408, 15556, 15703, 15848, 15991, 16133, 16273, 16412,
    16549, 16685, 16819, 16953, 17084, 17215, 17344, 17472,
    17599, 17725, 17849, 17973, 18095, 18217, 18337, 18457,
    18575, 18692, 18809, 18925, 19039, 19153, 19266, 19378,
    19489, 19600, 19710, 19819, 19927, 20034, 20141, 20247,
    20352, 20457, 20560, 20664, 20766, 20868, 20969, 21070,
    21170, 21269, 21368, 21466, 21564, 21661, 21758, 21854,
    21949, 22044, 22138, 22232, 22326, 22418, 22511, 22603,
    22694, 22785, 22875, 22965, 23055, 23144, 23232, 23321,
    23408, 23496, 23583, 23669, 23755, 23841, 23926, 24011,
    24095, 24180, 24263, 24347, 24430, 24512, 24595, 24676,
    24758, 24839, 24920, 25001, 25081, 25161, 25240, 25319,
    25398, 25477, 25555, 25633, 25710, 25788, 25865, 25941,
    26018, 26094, 26170, 26245, 26321, 26396, 26470, 26545,
    26619, 26693, 26766, 26840, 26913, 26986, 27058, 27130,
    27202, 27274, 27346, 27417, 27488, 27559, 27630, 27700,
    27770, 27840, 27910, 27979, 28048, 28117, 28186, 28255,
    28323, 28391, 28459, 28527, 28594, 28661, 28728, 28795,
    28862, 28928, 28995, 29061, 29127, 29192, 29258, 29323,
    29388, 29453, 29518, 29582, 29646, 29711, 29775, 29838,
    29902, 29965, 30029, 30092, 30155, 30217, 30280, 30342,
    30404, 30466, 30528, 30590, 30652, 30713, 30774, 30835,
    30896, 30957, 31017, 31078, 31138, 31198, 31258, 31318,
    31378, 31437, 31497, 31556, 31615, 31674, 31733, 31791,
    31850, 31908, 31966, 32024, 32082, 32140, 32198, 32255,
    32313, 32370, 32427, 32484, 32541, 32598, 32654, 32711
};

uint16_t* gamma_tables[2] = {
    (uint16_t*) srgb_gamma_table_256,
    (uint16_t*) srgb_revgamma_table_256
};

#if ENABLE_THREADS
pthread_mutex_t kd3_sort_lock;
#endif


const char* kc_debug_str(kcolor x) {
    static int whichbuf = 0;
    static char buf[4][32];
    whichbuf = (whichbuf + 1) % 4;
    if (x.a[0] >= 0 && x.a[1] >= 0 && x.a[2] >= 0) {
        kc_revgamma_transform(&x);
        sprintf(buf[whichbuf], "#%02X%02X%02X",
                x.a[0] >> 7, x.a[1] >> 7, x.a[2] >> 7);
    } else
        sprintf(buf[whichbuf], "<%d,%d,%d>", x.a[0], x.a[1], x.a[2]);
    return buf[whichbuf];
}

void kc_set_gamma(int type, double gamma) {
#if HAVE_POW
    static int cur_type = KC_GAMMA_SRGB;
    static double cur_gamma = 2.2;
    int i, j;
    if (type == cur_type && (type != KC_GAMMA_NUMERIC || gamma == cur_gamma))
        return;
    if (type == KC_GAMMA_SRGB) {
        if (gamma_tables[0] != srgb_gamma_table_256) {
            Gif_DeleteArray(gamma_tables[0]);
            Gif_DeleteArray(gamma_tables[1]);
        }
        gamma_tables[0] = (uint16_t*) srgb_gamma_table_256;
        gamma_tables[1] = (uint16_t*) srgb_revgamma_table_256;
    } else {
        if (gamma_tables[0] == srgb_gamma_table_256) {
            gamma_tables[0] = Gif_NewArray(uint16_t, 256);
            gamma_tables[1] = Gif_NewArray(uint16_t, 256);
        }
        for (j = 0; j != 256; ++j) {
            gamma_tables[0][j] = (int) (pow(j/255.0, gamma) * 32767 + 0.5);
            gamma_tables[1][j] = (int) (pow(j/256.0, 1/gamma) * 32767 + 0.5);
            /* The ++gamma_tables[][] ensures that round-trip gamma correction
               always preserve the input colors. Without it, one might have,
               for example, input values 0, 1, and 2 all mapping to
               gamma-corrected value 0. Then a round-trip through gamma
               correction loses information.
            */
            for (i = 0; i != 2; ++i)
                while (j && gamma_tables[i][j] <= gamma_tables[i][j-1]
                       && gamma_tables[i][j] < 32767)
                    ++gamma_tables[i][j];
        }
    }
    cur_type = type;
    cur_gamma = gamma;
#else
    (void) type, (void) gamma;
#endif
}

void kc_revgamma_transform(kcolor* x) {
    int d;
    for (d = 0; d != 3; ++d) {
        int c = gamma_tables[1][x->a[d] >> 7];
        while (c < 0x7F80 && x->a[d] >= gamma_tables[0][(c + 0x80) >> 7])
            c += 0x80;
        x->a[d] = c;
    }
}

#if 0
static void kc_test_gamma() {
    int x, y, z;
    for (x = 0; x != 256; ++x)
        for (y = 0; y != 256; ++y)
            for (z = 0; z != 256; ++z) {
                kcolor k;1]) {
              > 0)
data */
    if (subimage->->col[iobles[0][n */
   k    if (subimage->-    ik   x.a[0] )0; zxssed k7, x.a[1] )0; zy767)
                sed k7, 2.a[1] )0; z; ++z) {
                    kcolgame);
                       > 0)g
data */
    if (subimage->-        spristderrbuf], "#%02X%02X ->g ], 4X, 4X, 4X  optvg ], "#%02X%02X!\nmax)",
                        ata */
,olg", x.a[lg", 1.a[lg", 2]ax)",
                        k   x.a[0] >>k7, x.a[1] >>k7, x.a[2] >> 7);
















    asse>> 7);












    }
            ck;
#endi    static kchic_t * (abls[2] = {
40 103963 250655 263212   913, 15 14741943 12006   98, 914,
 71088 28456, 35, 2847, 36, 3, 2767
};

static voihic_tgr) (oihic_charhsal"tic voihic_tset (oihic_charhsma() {
    pe pi;
arh->hs[1] = Gif_NewAroihic_ite thkchic_t * (ables[0]);
arh->nhbuf = 0;
arh->capacienaltkchic_t * (abley, z;
    for (i = 0; iarh->capacien!= 2; ++i)
    arh->h>collor_coun0buf];
}

voihic_t /* cle(oihic_charhsma() {
    Gif_DeleteArarh->h)e pi;
arh->hs[1NULLbuf];oihic_ite *voihic_tadd(oihic_charh,     kcolthkchic_tlor_c_  int csma() {
/
  unsighash120hash2hbuf = 0;
aa   kcolae pi;
arhic_ite  *khpe pi;
aa.kaltke pi;
aa.a[3ed[i] = 0;      iarh->capacien++i)
    sedarh->nh>  ikrh->capacienama)0x80)4) ++i)
    arhic_tgr) (oih)e pi;
hash1][j] ika   x.a&(c < E 0x<< 152767)
         |  ika   1.a&(c < E 0x<< 52767)
         |  ika   2.a&(c < E 0x80)5) + 1arh->capacien!
32];
    whi) > 1) {
    khp][j&arh->h>hash1>> 7];
        iahirmapuparent
        sed    mp 0)hirmk_datk_data, sizkgam[x]] == 0)
            break;
        ihash2 ++z) {
        hash2hbu] ika   x.a&(c 03FF0x<< 20data)
                 |  ika   1.a&(c 03FF0x<< 10data)
                 |  ka   2.a&(c 03FF0 + 1arh->capacien!
) {
        hash2hbuhash2h?uhash2h:ed = 1;
        }
    hash1]+buhash2reak;
        hash1]>ize = (unsignarh->capacien)
) {
        hash1 - iarh->capacien!= c;
   0;      iahirmapupa > 1) {
    khprmk_altk data;
    ++arh->nnfo);
    }
ahirmapupaRED] += cturn;
    ahirmapupaR< int cs1) {
    khprmlor_coun(kchic_tlor_c_ ) -1[2]);
    retkhpe }7
};

static voihic_tgr) (oihic_charhs> 1) {
oihic_ite *voldh  iarh->h 2.2;
    intoldcapacienaltkch->capaciena?tkch->capaciena: arh->nnfo);
    for (i =kchic_t * (abii][j]oldcapacien!= 2; ++i)
    

  /*cy, nothin = 0;
arh->capacienaltkchic_t * (abing[i];
arh->hs[1] = Gif_NewAroihic_ite thkch->capacien)[0]);
arh->nhbuf = 0;
    for (i = 0; iarh->capacien!= 2; ++i)
    arh->h>collor_coun0bu 0;
    for (i = 0; ioldcapacien!= 2; ++i)
        ildh>collor_c)
) {
        oihic_tadd(oihntoldh>colaa.kntoldh>collor_count);
;
  Gif_DeleteArrldh)buf];
}

voihic_t aseComp(oihic_charhsma() {
    pnt i, j;
    for (int altkch->n = 0; iarh->n = ++i)
        arh->h>collor_c)
) {
         2;data;
        else arh->h>jollor_c)++z) {
        arh->h>co  iarh->hs[i][j];
         2;+curjgfi);
        } [j];
         2j = 0;
arh->capacienalt0buf];
}

voihic_then (oihic_charh, ta)(Gif_St*ta), gray(32nt16n  X(trastoresma() {
/ay(32nt g] = cou56.a[l] = cou56.;() {
/ay(32nt nfs->backgrounintn y, transparen0 2.2;
    ata */ol, i, imagei  oihic_tset (oih) = 0;

    for (i = 0; i != 256; ++i)
    g] = coied[i] = 0;      /* Coed" pixels */
    for (imagei = 0; imagei < gfs->nimag56;0; imdata) {
        ssedI*ta)r_gfi = gfs->images[iii][j];
    ;
  Gie_colo*ta)cmr_t2 = gd a lo?t2 = gd a lo:;

  gfs->gl][j];
    ray(32nt16lor_coun2 = gd a lo?tl] = co:;
 += cturn;
) {
/ay(32nt rld use_transpt_lor_coun0bu 0;
.2;
     If  was_compressedcur_gfi->img == +i)
        !a)cm> 7])
         ontinue= +i)
        lor_cou=tl] = c ++y)
            for (i = 0; i != 256; ++i)
             o= coied[i] =+i)
        cur_gfi->transparent >= 0)
        rld use_transpt_lor_coun o= cocur_gfi->transpa]map);

  

    om unoptifrom the imata if necessary */
         If  was_compre>= 0)
        ;
  easeUncompressImage(gfs,)map);

  

   sweepwins over the imous_da o= ccurrid" pixels */
        for (y = 0; cur_gfi->height; ++y) {
         on const 8nt16ser_datcur_gfi-[yi][j];
            for (x = 0; h = gfi->wi256;,     ++ ++i)
            ++ o= co8_t *i][j];
      p);

  

   om,  o= cf used colto the gloh - Histo  || (l  If )sary */
        if (gfi->local)
            for (i = 0; ia)cmrmap->n256; ++i)
                if (coiANSP] 0; ia)r_gfi->transpadata)
                oihic_tadd(oihntkcthen a)cg(&a)cmrmap->co),  o= coie) =+i)
        cur_gfi->transparent ata)
        SP] && cocur_gfi->transpa]0; iold use_transpt_lor_c ++y) {
        n y, transpar+un o= cocur_gfi->transpa] -iold use_transpt_lor_c;y) {
         o= cocur_gfi->transpa]  iold use_transpt_lor_c][j];
      p);

  

   hat in this imame  on background disp,  o= c itsmage stowardsr of the
        on backgr' sets pi o= c ary */
        if (gfi->disposal == GIF_DISPOSAL_BACKGROUND)
        nfs->backgro+ize = (unsigncur_gfi->width = (unsigncur_geen_height;

  

   rip w are was_compresthe imata if necessary */
         If  was_compre>= 0)
        ;
  Gif_ReleaseUncompressedImage(gf      p);

    if= gfs->ima0]_gfi->transpar<t ata)
        
  gfs->glo    
  gfs->backgro<  
  gfs->glrmap-> ++i)
    g] = co 
  gfs->backgrIRED]nfs->backgrgfi);
    ++i)
    n y, transpar+unnfs->backgrgfp);

    if= gfs->gl ++x)
        for (i = 0; ia)  gfs->glrmap->n256; ++i)
            i o= coie)ata)
            oihic_tadd(oihntkcthen a)cg(&a)  gfs->glrmap->co), g o= coie) = 0;     n/* Nhen mver linearoh - Histo ata from hashsigh - Histo ary */
oihic_t aseComp(oih(gf    *n  X(trastorer (na = transpare}di    static equioihic_ite _ to com( on co
}

* v_da on co
}

* vb ++y) {
 on cooihic_ite *vassed on cooihic_ite *) v_;y) {
 on cooihic_ite *vbssed on cooihic_ite *) vb[2]);
    retarmk_   x.a- brmk_   x.re}di    static g, scroihic_ite _ to com( on co
}

* v_da on co
}

* vb ++y) {
 on cooihic_ite *vassed on cooihic_ite *) v_;y) {
 on cooihic_ite *vbssed on cooihic_ite *) vb[2]);
    retarmk_   1.a- brmk_   1.re}di    static blueroihic_ite _ to com( on co
}

* v_da on co
}

* vb ++y) {
 on cooihic_ite *vassed on cooihic_ite *) v_;y) {
 on cooihic_ite *vbssed on cooihic_ite *) vb[2]);
    retarmk_   2.a- brmk_   2.re}di    static pop regienroihic_ite _ to com( on co
}

* v_da on co
}

* vb ++y) {
 on cooihic_ite *vassed on cooihic_ite *) v_;y) {
 on cooihic_ite *vbssed on cooihic_ite *) vb[2]);
    retarmlor_counbrmlor_co256 ? -armlor_co; ibrmlor_cre}di    static pop regienrkd3_s to com( on co
}

* v_da on co
}

* vb ++y) {
 on co;
  Gie_c*vassed on co;
  Gie_c*) v_;y) {
 on co;
  Gie_c*vbssed on co;
  Gie_c*) vb[2]);
    retarm[P].pixibrm[P].pi256 ? -arm[P].pi; ibrm[P].pata);
}
OBAL COLO FUNCLIZAS
    retat;
 he b (a vectorpart;
  Gie_cdlesTof the[P].pifielbounrerted fined;from has[P].pifielbounrerd 2 0= x). id) d fa
   stma() {
     on f 2.2;
    age ;() {
/ay(32nt [P].pata omap->actsloeigh;
  Gie_colo*tpt->colore immn_cut(oihic_charh, tt_Outpuf_OptD odlags)
)
{
  imap-reen_sizod opt->colorage ;() {
omap->actsloe *sloess[1] = Gif_NewAromap->actsloe, imap-reen_ount);
;
  Gie_coloreamcmr_tp = Gif_NewFullColorimap-reen_16_t, 256);
;
  Gie_c *imap-  ia)cmrmp->ncolt2;
  iimap- 2.2;
    int ,tke  0;     
   Trce cwme The writall wre differency pmand q by J faPoskanzerax)",
    is part in tbmplule ickt ima11) */

    imap-reen_s< 2 sedimap-reen_sunt > ++x)
        fatal_erromap->act;
 he b een_sata mbrence betw2, 1, a56"info);
    imap-reen_su iarh->no   !od opt->colorfP].e>= 0)
    war run(1, "trivinitomap->act;
 he b age (o%d %nd ishis so max)",
            arh->n,
arh->nhbme =? "pt->c"? -"pt->cs"info);
    imap-reen_su iarh->nIOUS)
     map-reen_sizarh->nnf 0;     0= eed[re, 1y the transparent c ata f on iderforma; equprodomap->acx)",
    i he b een_sing c tomo* updUse transparencyitould slook ures  (it'lx)",
    if necessary */
    imap-reen_sunto   imap-reen_s< arh->no   arh->nocol 65ata)
       od opt->colorpt->s use_transpareOUS)
     map-reen_--nf 0;     1.  /* set uey on fisloe, ust connothi(itid" piosal. */
sloes x.. on fibuf = 0;
 loes x..een_sizarh->nnf 0;
 loes x..[i].pixe0bu 0;
    for (i = 0< arh->nncol; i++)
     loes x..[i].pi+ iarh->hscollor_cnf 0;     2.  plifisloes = ccln soght  en thr.xels */
    fnimap-  i1; iimap-1; imap-reen_; iimap-agei++) {
    omap->actsloe *splifi[i] =+i)
        kcominc Nhexc =+i)
      hic_ite  *sliceight;

  

   2.1. and pick sloe ent plif.sary */
    +y) {
        /ay(32nt  plif_[i].pixe0bu 0;
+x)
        for (i = 0< iimap- col; i++)
                iloes i..een_snd]      loes i..[P].pixi plif_[i].p ++z) {
                splifi[i& loes i.> 7);
















 plif_[i].pixe loes i..[P].p> 7);












    }
            ! plif i++)
                break;
    }i++)
     lierlac&arh->h> plif-> on f]ight;

  

   2.2.  /* fitsmextsparsary */
    +y) {
          hic_ite  *usevixe liceig) {
        mincdata xcdata =vrmk_ kbu 0;
+x)
        for (1same,v++ = 0<  plif->een_; ol;same,v++ i++)
                fkr (i =k0; d != 3k ++z) {
                minc   k]  imin(minc   k],ta =vrmk_   k]r_t2);
                  xc   k]  imax(  xc   k],ta =vrmk_   k]r_t2);
            }eak;
    }iht;

  

   2.3.  /*ide how ent plif if.sust use luminaferemethod.hi(so  /* t2);
       ve (th6 colors. */
    +y) {
        tic douequid <0  (i.299idth  xc   x.a- minc   les[0]);
        pe, doub, scrd <0  (i.587idth  xc   1.a- minc   1es[0]);
        pe, doubluerd <0  (i.114idth  xc   2.a- minc   2es[0]);
            equid <0 [d] , scrd <0    equid <0 [d]bluerd <0 i++)
            q /* ( lice,  plif->een_data, sizk hic_ite ), equioihic_ite _ to coms[0]);
            else  , scrd <0 [d]bluerd <0 i++)
            q /* ( lice,  plif->een_data, sizk hic_ite ), g, scroihic_ite _ to coms[0]);
            i++)
            q /* ( lice,  plif->een_data, sizk hic_ite ), blueroihic_ite _ to com 256);
      ht;

  

   2.4.  /*ide we. T ent plif ick sloe map aplif if ickre.sary */
    +y) {
        /ay(32nt half_id" pix=  plif->[i].pi/ 2;y) {
        /ay(32nt [i].p_ c umixe lice x..lor_c;y) {
        /ay(32nt d <01, d <02bu 0;
+x)
        for (1 = 0<  plif->een_ncol    [i].p_ c umi< half_id" pi col; i++)
            [i].p_ c umi+xe lice collor_cnf 0;  t;

  

   We kand  as the aba. Befick splif ame ome mid" pixter thani++)
           the aeft a,y if posy by a     lam    is(badta +dlesIcyiti++)
           rd (we to shrink m    i,  /* chaick splif.     */
        d <01amma*[i].p_ c umi-  plif->[i].p;  */
        d <02x=  plif->[i].pi-ma*([i].p_ c umi-  lice c-1ollor_count);








lse d <02x< d <01aSP] 0SK) > 1) {
      





l--nf++)
            [i].p_ c umi-xe lice collor_cnf            }f 0;  t;

  

 loes iimap-.. on fibu plif-> on f + i; 0;  t;

  

 loes iimap-..een_siz plif->een_ncoi; 0;  t;

  

 loes iimap-..[i].pixe plif->[i].pi-m[i].p_ c um; 0;  t;

  

 plif->een_n=oi; 0;  t;

  

 plif->[i].pi=m[i].p_ c um; 0;  t;

    }
    }

   3. hen mver ake  i he b by  /* cemoving one coata ffor e loe.xels */
    for (i = 0< iimap- col; > 1) {
    pe, doupx[3.> 7);




oihic_ite *v lierlac&arh->h>e loes i.. on f .> 7);




oi  kcolc =+i)
    px[les[0px[1es[0px[2ed[i] =+i)
        for (j = 0; jiloes i..een_ 256; u 0;
+x)
        fkr (i =k0; d != 3k f++)
            [x k] +xe lice jolaa.  k] dthpe, do)e lice jollor_cnf        kc   x.a[j] = (intx[les/e loes i..[P].p)nf        kc   1.a[j] = (intx[1es/e loes i..[P].p)nf        kc   2.a[j] = (intx[2es/e loes i..[P].p)nf        imap->co  iar_toa)cg(&kc(gf      p);

;
  Gif_DeleteAr loes(gf    a)cmrmap->r (nimap- 2.2;
    reta)cmata);

}

voidi
   vtytset (oidi
   vty* d vthkchic_charh,     iodck eisma() {
    pe pi;
d vrmkch  iarhe pi;
q /* (arh->h, arh->n,
ta, sizk hic_ite ), pop regienroihic_ite _ to com)e pi;
d vrmcion lts[1] = Gif_NewAriparearh->nIe pi;
d vrmmin_py, s[1] = Gif_NewArray(32ntrearh->nIe pi;
    for (i = 0; iarh->nn256; ++i)
    d vrmmin_py, >co  irray(32nt) -1[2]);
lse dodck eisma() {
    d vrmmin_pyk ei_py, s[1] = Gif_NewArray(32ntrearh->nIe pi;
pi;
    for (i = 0; iarh->nn256; ++i)
        d vrmmin_pyk ei_py, >co  irray(32nt) -1[2]);
    } [j];
    d vrmmin_pyk ei_py, s[1NULLbupi;
d vrmchon ns[1] = Gif_NewAriparearh->nIe pi;
d vrmnchon ns[10buf];
}

voidi
   vtyt /* cle(oidi
   vty* d vsma() {
    Gif_DeleteArd vrmcion ltount);
;
  Gif_DeleteArd vrmmin_py, ount);
;
  Gif_DeleteArd vrmmin_pyk ei_py, ount);
;
  Gif_DeleteArd vrmchon n)buf];tic kcdi
   vtyt /* _pop reg(oidi
   vty* d vsma() {
    intns[1d vrmkch->nnfo);
    for (i = 0; ino   d vrmmin_py, >co   (i = 2; ++i)
    

 spinhin = 0;
    retibuf];tic kcdi
   vtyt /* _di
   e(oidi
   vty* d vthpe, doupyk eiwi->heima() {
    intns[1d vrmkch->n,  /on ns[1kcdi
   vtyt /* _pop reg(d vs[2]);
lse  /on ns[ in ++i)
    

 skiphin = 0;
    else !pyk eiwi->he sed!d vrmmin_pyk ei_py, oma() {
        for ( /on ns+(1 = 0; inn256; ++i)
            d vrmmin_py, >co > d vrmmin_py, > /on ne)ata)
             /on ns[1i[2]);
    } > 1) {
    pe, dou  x_py, s[1d vrmmin_py, > /on ney U1 k eiwi->he * d vrmmin_pyk ei_py, > /on nee pi;
pi;
    for ( /on ns+(1 = 0; inn256; ++i)
            d vrmmin_py, >co !me == 0) {
            pe, doupy, s[1d vrmmin_py, >iey U1 k eiwi->he * d vrmmin_pyk ei_py, >i.> 7);












    d scoun  x_py,  ++z) {
                 /on ns[1i[2]);
















  x_py, s[1d st[2]);












    }
                        ret /on nbuf];tic kcdi
   vtyt /* ce(oidi
   vty* d vth    i/on n,     iodck eisma() {
    pnt ,tkntns[1d vrmkch->nnfo);
oihic_ite *vhy, s[1d vrmarh->h 2 pi;
d vrmmin_py, > /on neyen0 2.2;
    d vrmmin_pyk ei_py, o[j];
    d vrmmin_pyk ei_py, > /on neyen0 2.2;
d vrmcion lt> /on neyen /on nbu  }

   ad we jink min_py, sno wyxels */
    for (i = 0; inn256; ++i)
        d vrmmin_py, >co ++z) {
        /ay(32nt d , s[1ar*  , afer(&hy, >colaa.knt&hy, > /on nelaa.kount);








lse d stx< d vrmmin_py, >co ++z) {
        pi;
d vrmmin_py, >co  id st[2]);












d vrmcion lt>ieyen /on nbu











    }
        }

   i(so  c tr_co    pyk ei   , aferssary */
    iodck eio   d vrmmin_pyk ei_py, o[j];
        for (i = 0; id vrmnchon nn256;  +y) {
          r(kcolhbuhy, > /on nelaa.k, *or (&hy, >d vrmchon nring.k_ kbu 0;
+x)
        eX(fina wasbinformastall w    laluminafered <0differe    */
        de, doupLr (abp(oi_luminaferformi-moi_luminaferfy)s[0]);
        pLr ((pLr>067,2h?upLr* 4s/e] < 3.h:ed 0.5);
               crewasbinforma     */
            fkr (i =k0; d != 3k f++)
            x   k]  i(x   k] + y   xk]0x80)10.5);
           track cion nexprefewasbinforma totype otsed col    */
            for (j = 0; jn 256; u 0;
+x)
     */
    i vrmmin_py, >jo ++z) {
        pi;
    de, doup , s[1ar*  , afer(&hy, >jolaa.knt&xammadL[2]);
















lse d stx< d vrmmin_pyk ei_py, >je)ata)
            pi;
    d vrmmin_pyk ei_py, >je  irray(32nt) d st[2]);












    }
    }2 pi;
d vrmchon nrd vrmnchon neyen /on nbu



++d vrmnchon nn         ret /on nbuf];};

static vpt->colordi
   vtytdo_ dond(oidi
   vty* d vsma() {
    int ,tkntns[1d vrmkch->nnfo);
oihic_ite *vhy, s[1d vrmarh->h 2) {
   *t /on nbal_map = Gif_NewAriparenIe pi;
scalepare_c* d _map = Gif_NewArscalepare_c,id vrmnchon nIe pi;
    for (i = 0; id vrmnchon nn256; [j];
        fkr (i =k0; d4!= 3k f++)
        di>col  k]  i0bu 0;
    for (i = 0; id vrmnchon nn256; [j];
     /on nbal>d vrmchon nrings[1i[2]);
    for (i = 0; inn256; > 1) {
    pe, doulor_counhy, >collor_cnf            i vrmcion lt>ieye[1i> 7])
         o= c a d ! 7])
    jyen /on nbal>d vrmcion lt>ieee pi;
pi;
    fkr (i =k0; d != 3k f++)
        di>jol  k] +unhy, >colaa.  k] dtlor_cnf        di>jol  3]RED] += cturn;
}u 0;
    for (i = 0; id vrmnchon nn256; ++d) {
        match  id vrmchon nrinnf            i >col  3>a[d]5 *vhy, [matchollor_c)
) {
            fkr (i =k0; d != 3k f++)
            hy, [matcholaa.  k] [j] = (indi>col  k] / i >col  3>info);
    }
    Gif_DeleteAr /on nbalount);
;
  Gif_DeleteArd data);
};

sta;
  Gie_colore
pt->colordi
   vty(oihic_charh, tt_Outpuf_OptD od,atic blondlags)
)
{
  imap-reen_sizod opt->colorage ;() {
oidi
   vtyid vunt);
;
  Gie_colo*ta)cmr_tp = Gif_NewFullColorimap-reen_16_t, 256);
;
  iimap-yen0 2.2;
    i/on ne  0;     
   Trce cwme un loXV'e omd <ieroun
   vtyiedy algor0, 1, wme The wrif++)
   all wre differencyXV'e  X(simentforma art iing ay algoriby John Bradlen++i)
   <bradlen@cis.u eXn.edu>, 1, Tom Lane <Tom.Lane@g.gp.cs.cmu.edu>ma11) */

    imap-reen_s< 2 sedimap-reen_sunt > ++x)
        fatal_erromap->act;
 he b een_sata mbrence betw2, 1, a56"info);
    imap-reen_suiarh->no   !od opt->colorfP].e>= 0)
    war run(1, "trivinitomap->act;
 he b age (o%d sed col ishis so maearh->nIe pi;
    imap-reen_suiarh->nIOUS)
     map-reen_sizarh->nnf 0;     0= eed[re, 1y the transparent c ata f on iderforma; equprodomap->acx)",
    i he b een_sing c tomo* updUse transparencyitould slook ures  (it'lx)",
    if necessary */
h>

t GIF will if necessing c tomo* updUse transparencyi) >ickrecost is
  dUse transparenur in the i; (2)  as tmap->act;
 he b is* dotrivinid it;t is
  d(3 >ickrecnrerdl be smnuRememore of csenur in the i  irbiUsew, trn, aft:++i)
   <ol 65)stic,it'slook  applingthe mfs->im GIF wust the mart in  loesstic++i)
   it'slook  applkrecwoouldn'tunupres loes.sary */
    imap-reen_sunto   imap-reen_s< arh->no   arh->nocol 65ata)
       od opt->colorpt->s use_transpareOUS)
     map-reen_--nf 0;     blondemovame  od e<0dcts we.n>ickrecnrer
  y fewtsed col    */
    imap-reen_s< 4eOUS)
    blond [i] = 0;     1. set i(fina min_py, snap aort ve (th6 coenurordmemorepop regien. ary */
oidi
   vtytset (&d vthkch, od opyk ei_&& (typepyk ei_none)nf 0;     2.  /* ce(th6 coeing ing next tels */
    fnimap-  i0; iimap-1; imap-reen_; iimap-agei++) {
       2.1.  /* ce(ve (th6 cdata toade enary */
        nimap-  1] >sed nimap- [d]1x7F80nimap- %ntoimg = f++)
           2.1a. wanngthe mpop regr to/on nsth6 cd    */
         /on ns[1kcdi
   vtyt /* _pop reg(&d vs[2]);




    else od opyk ei_&& (t=pepyk ei_none)f++)
           2.1b.  /* ce(bapresma un
   vtyisal froo/on nsth6 col    */
         /on ns[1kcdi
   vtyt /* _di
   e(&d vth0s[2]);




    e{f++)
           2.1c.  /* ce(bapresma un
   vtyisal froo/on nsth6 coages, e sowf++)
          epyk eif usesbinformastent tnap iation th6 coag is ic reg apeeg af++)
          ema in(ve (th6 cd /* currirof nel    */
           We->he as  unsigentpyk eif usesbinformastdropsg
  now rof mplied.) {
#if HAVE_POW
       epe, doupyk eiwi->he  (i.05 + t) (0. 1892datanimap- -K) >/ 3.)amma;
#else
       epe, doupyk eiwi->he  (iimap-1; 4 ?(i.25 :(i.125amma;
#en */
         /on ns[1kcdi
   vtyt /* _di
   e(&d vthpyk eiwi->hei256);
      ht;

  

kcdi
   vtyt /* ce(&d vthi/on n,ata)
            pi;
      emd opyk ei_&& (typepyk ei_noneata)
            pi;
      eF80nimap- > x7F80nimap- < 64_gfi);
    }

   3. hen mver ake  i he b by  /* cemoving one coata ffor e loe.xels */
lse blondla         t->colordi
   vtytdo_ dond(&d vs[2s */
    fnimap-  i0; iimap-1; id v.nchon nn256iimap- ++i)
    g)cmrmap->iimap-.  iar_toa)cg(&kch->h>d v.chon nriimap-.elaa.kount);
a)cmrmap->r (nimap- 2y */
oidi
   vtyt /* cle(&d vs[2]);
    reta)cmata);
;
  Gie_colo*tpt->color dondrdi
   vty(oihic_charh, tt_Outpuf_OptD odei++) {
    ret t->colordi
   vty(oih, od,a1data);;
  Gie_colo*tpt->colorflatrdi
   vty(oihic_charh, tt_Outpuf_OptD odei++) {
    ret t->colordi
   vty(oih, od,a0data);
}


/*****kd useerd 2ocforma nds aed 2ocformaTION
 **/  stmx_t useeposma() {
    pivo- 2.2;
    offsecre}al"tic vo_t set (o_t usee**kd3,atic v(*0][n */
 )form(kco)s> 1) {
od3_gfiees[1NULLbupi;
od3_gkss[1] = Gif_NewArkare_c,i_t, 256);
od3_gnite syen0 2.2;
od3_gite s_cal_mable_256;
od3_gfi[n */
  ata = t*/
 _256;
od3_gxradiuss[1NULLbupi;
od3_gpy,ma_td [i-1[2}l"tic vo_t  /* cle(o_t usee**kd3sma() {
    Gif_DeleteArad3_gfieeount);
;
  Gif_DeleteArod3_gksount);
;
  Gif_DeleteArod3_gxradius)[2}l"tic vo_t ade[0][n */
 ed(o_t usee**kd3,a on cooire_c* k ++z) {
lse ad3_gnite sye=
od3_gite s_cal > 1) {
    kd3_gite s_cal_*= 2;y) {
    ;
  GileteArod3_gks,     kc,
od3_gite s_cal nfo);
    }
od3_gks[ad3_gnite s.  i*kbu



++ad3_gnite s;z) {
lse ad3_gfieeoata) {
        Gif_DeleteArad3_gfieeount);
t);
;
  Gif_DeleteArod3_gxradius)[2) {
    kd3_gfiees[1NULLbupi;
56;
od3_gxradiuss[1NULLbupi;
}2}l"tic vo_t ade8g(o_t usee**kd3,a{
  i0,a{
  i1,a{
  i2 ++z) {
    kcolor k;1       > 0)
di0,ai1,aa2);z) {
lse ad3_gfi[n */
 )2) {
    kd3_gfi[n */
   k    if o_t ade[0][n */
 ed(o_tdatk)buf];};

stao_t usee**kd3rkd3_er;di    static k_t ste _ to co_0( on co
}

* _da on co
}

* b ++y) {
 on co   *taassed on co   *) _da*bbssed on co   *) b[2]);
    retkd3rkd3_er_gks[*aa]   x.a- kd3rkd3_er_gks[*bb]   x.re}di    static k_t ste _ to co_1( on co
}

* _da on co
}

* b ++y) {
 on co   *taassed on co   *) _da*bbssed on co   *) b[2]);
    retkd3rkd3_er_gks[*aa]   1.a- kd3rkd3_er_gks[*bb]   1.re}di    static k_t ste _ to co_2( on co
}

* _da on co
}

* b ++y) {
 on co   *taassed on co   *) _da*bbssed on co   *) b[2]);
    retkd3rkd3_er_gks[*aa]   2.a- kd3rkd3_er_gks[*bb]   2.re}di    static (*k_t ste _ to cos[])( on co
}

*da on co
}

*) [2] = {
&k_t ste _ to co_0,
&k_t ste _ to co_1,
&k_t ste _ to co_22767
};

static k_t ste _d 2_ to co( on co
}

* _da on co
}

* b ++y) {
 on co   *taassed on co   *) _da*bbssed on co   *) b[2]);
    ret    mp 0)d3rkd3_er_gks[*aa],
&k_t kd3_er_gks[*bb],
ta, sizk   kc))re}di    static k_t build_s str(   *tperm,a{
  nperm,a{
  n,     iepths> 1) {
od3 usee**kd3 =*kd3rkd3_er;d.2;
    m,anl,anc,
aage_indeiepth %n3 2.2;
    depth > kd3_gmaxiepths2) {
    kd3_gmaxiepthndeiepth 2.2;
    whinsu iad3_gnfieeoata) {
    ad3_gnfiee_*= 2;y) {
    ;
  GileteArod3_gtif_Frx_t useepos,iad3_gnfieeonfo);
    }
    npermocol1oata) {
    ad3_gfiee[n..[Pvo-ssednpermo 1] >256 ? -perm les[0]);
    ad3_gfiee[n..offsec [i-1[2]);
        ret2gfi);
    }

q /* (perm,anperm,ata, siz = (, k_t ste _ to cos[aage_ie) = 0;     and p[Pvo-: a one co to ingne ent plifxels */
  atnpermo80)10.5);
    whimndex > 0
      o   ad3_gks[perm m]]   aage_ieye=
od3_gks[perm m-1]]   aage_ies2) {
    --m 2.2;
    mo 1] oat     /* do plifxgneir  appal to Copyriginfset eouldp)sary */
      atnpermo80)10.5);
5);
    whimn<tnpermocol    i(so,  /* do plifxgneir  appal to fi->l    */
          o   ad3_gks[perm m]]   aage_ieye=
od3_gks[perm m-1]]   aage_ies2) {
        ++mnfo);
    }
    m[x]] == 0)
    ad3_gfiee[n..[Pvo-ssead3_gks[perm m]]   aage_ie = 0;
    = 0)
    ad3_gfiee[n..[Pvo-ssead3_gks[perm m-1]]   aage_ie2) {
        +  ikd3_gks[perm m]]   aage_iey-
od3_gks[perm m-1]]   aage_ieso80)1) = 0;     recu  el    */
nl =*kd3rbuild_s str(perm,am,an+1, depth+1 256);
od3_gfiee[n..offsec [i1+np;  */
nr =*kd3rbuild_s str(&perm m],tnpermocom,an+1+nl,adepth+1 256);
    ret1+nl+nr;   }
}

#if 0
static vod3r   sp_depth(o_t usee**kd3,a{
  depthFrx_t useepos  aax)",
                           *ta,    *tbsma() {
    i256);
tic cx[6][1ley, z;
    for (i = 0; i3n256; ++d) {
        i>ieye[1INT_MINs2) {
            sprix[2*ihbuf*"s[2]);




    2) {
            sprix[2*ihbuf%d",
aoie) =+i)
        b>ieye[1INT_MAXs2) {
            sprix[2*i+1hbuf*"s[2]);




    2) {
            sprix[2*i+1hbuf%d",
boie) =+i)
    }
   spri"%*s<%s:%s,%s:%s,%s:%sd,%ddepth*3,a"max)",
       x x.a[0 x.a[1 2]a x[3.a x[4.a x[5]);z) {
lse p->offsec <e == 0) {
    lse p->[Pvo-s[2] >= 0) {
            assod3_gks[p->[Pvo-]f (x.a[0]  les[0]);
            assod3_gks[p->[Pvo-]f (1.a[0]  1es[0]);
            assod3_gks[p->[Pvo-]f (2.a[0]  2es[0]);
            assod3_gks[p->[Pvo-]f (x.a<
boles[0]);
            assod3_gks[p->[Pvo-]f (1.a<
bo1es[0]);
            assod3_gks[p->[Pvo-]f (2.a<
bo2es[0]);
           spri" ** @%d: ], "<%d,%d\nma p->[Pvo-, od3_gks[p->[Pvo-]f (x., od3_gks[p->[Pvo-]f (1., od3_gks[p->[Pvo-]f (2es[1]);
        }
    } else {
     
  iage_indeiepth %n3a x[3.[1]);
        assp->[Pvo-s[2]a[aage_ie) =]);
        assp->[Pvo-s<
boaage_ie) =]);
       spri(iage_ind1] >25" | ], "_,_d\nm :x)",
            iage_ind1]1>25" | ]_"<%d_d\nm :5" | ]_"_d,%d\nm)a p->[Pvo-) =]);
        py(x,
b,ata, siz = (ama)0 =]);
    x aage_ieye p->[Pvo-[0]);
    ad3r   sp_depth(o_t%ddepths+(1a ps+(1a a, x) =]);
        py(x,
a,ata, siz = (ama)0 =]);
    x aage_ieye p->[Pvo-[0]);
    ad3r   sp_depth(o_t%ddepths+(1a ps+(p->offsec
datab) =+i)
  }7
};

static vod3r   sp(o_t usee**kd3sma() {
 
  i[3.a b[3.[1]);
  x.a[j  1.a[j  2.a[jINT_MIN[1]);
b x.a[jb 1.a[jb 2.a[jINT_MAX   if o_t    sp_depth(o_t%d0,
od3_gfiee,
a,ab)re}dck;
#endtic vod3rbuild_xradius(o_t usee**kd3sma() {
 
  pnt i, j;
       crexradiussels */
lse od3_gxradius)2]);
        re_256;
od3_gxradiuss[1] = Gif_NewArr= (unsi,iad3_gnite sIe pi;
    for (i = 0; iad3_gnite s;= 2; ++i)
    ad3_gxradius>co  irr= (unsign-1[2]);
    for (i = 0; iad3_gnite s;= 2; ++i)
        for (is+(1 =j0; iad3_gnite s;= 2; ++j) {
        /
  unsigp , s[1ar*  , afer(&od3_gks[i],
&k_t_gks[jes[0]);
        /
  unsigradiuss[1p , s/1) % 4;








    eadiuss< ad3_gxradius>co)ata)
            od3_gxradius>co  iradius % 4;








    eadiuss< ad3_gxradius>je)ata)
            ad3_gxradius>je  iradius % 4;




}2}l"tic vo_t build(o_t usee**kd3sma() {
 
  pntdels_da*perm[1]);
    ass!ad3_gfieeoun, j;
       crefiee_*/56);
od3_gfiees[1] = Gif_NewArk_t useepos,i_t, 256);
od3_gnfiees[1ble_256;
od3_gmaxiepthnde0un, j;
       crecan moreite s;=eed[re,duplic crssels */
permo 1] = Gif_NewAriparead3_gnite sIe pi;
    for (i = 0; iad3_gnite s;= 2; ++i)
    perm igs[1i[2};

#if ENABLE_THRE j;
  ++i)
 * Becaust kd3rkd3_ere
  a
    stafs->gloupres ishime++i)
 * kd3_emov to coat coag s, e ead_m aackgro in ++i)
 * rce cbort_sing tic van ut_erec castrophetion.
 els */
pDS
pthread_muort_ 0)d3rkd3_uort_)lock;
#end56;
od3rkd3_ere iad3;  }

q /* (perm,aad3_gnite s,ata, siz = (, k_t ste _d 2_ to coIe pi;
    for (intdels_  (1 = 0+tdels_ <iad3_gnite s;= 2; ++i)
        m   mp 0)d3_gks[perm i]],
&k_t_gks[perm i+dels_]]ax)",
               ta, sizk   kc))[x]] == 0)
        ++dels_da--;data;
        else dels_ 0)1)0]);
         erm i+1es[0perm i+dels_];nd56;
od3rbuild_s str(perm,aad3_gnite sy-e dels_ -K) %d0,
0s[2]);
    assod3_gmaxiepthn[j] )56
};

#if ENABLE_THRE */
pDS
pthread_muunort_ 0)d3rkd3_uort_)lock;
#en */
;
  Gif_DeleteArperm)[2}l"tic vo_t set  build(o_t usee**kd3,atic v(*0][n */
 )form(kco)ax)",
                 on co;
  Gie_colo*ta)cmsma() {
    pe pi;
a_t set (o_t,ta = t*/
 Ie pi;
    for (i = 0<ia)cmrmap->n256; ++i)
    o_t ade8g(o_t, a)cmrmap->co.a)c_rsi,ia)cmrmap->co.a)c_g, scax)",
              a)cmrmap->co.a)c_blue    if o_t build(o_t)buf];tic k_t  /on lt[0][n */
 ed(o_t usee**kd3,a on cooire_c* kax)",
                        /
  unsi*1p , astoresma() {
 on coo_t useepos     ckf[4][32];
nst 8nt
    ef[4][32];
    a  ckposmen0 2.2;
    resulc [i-1[2]);
/
  unsigm/* c, s[1rr= (unsign-1[2s */
lse !ad3_gfieeo++i)
    o_t build(o_t)bu++i)
   ckfx.a[jad3_gfiee;++i)
   tefx.a[j0un, j;
    whia  ckposm[2] >= 0) {
     on coo_t useepos  p =]);
        assa  ckposm[j] )56         a[j   ckfa  ckpos]ight;

  

lse p->offsec <e == 0) {
      

lse p->[Pvo-s[2] o   ad3_gpy,ma_td !e p->[Pvo- ++z) {
        pi;
/
  unsigp , s[1ar*  , afer(&od3_gks[p->[Pvo-],aar_t2);
            lse d stx< m/* c,  ++z) {
                minpy, s[1d st[2]);
















resulc [ip->[Pvo-[0]);
                }
                      lse --a  ckposm[2] >0]);
            ++   tefa  ckpos]ig              else    tefa  ckpos]o 1] oat             lse k   xa  ckposm%n3.a<
p->[Pvo- 0]);
               ckfa  ckposs+(1es[0ps+(1 0]);
            i++)
               ckfa  ckposs+(1es[0ps+(p->offsec 0]);
        ++   ckpos 0]);
           tefa  ckpos]o i] =+i)
        } else {
        l
  dels_  (k   xa  ckposm%n3.a-ip->[Pvo-[0]);
        lse    tefa  ckpos]o 1]1i++)
            ype r= (unsign dels_ * dels_)x< m/* c,  ++z) {
            lse dels_ <] >0]);
                   ckfa  ckposs+(1es[0ps+(p->offsec 0]);
                i++)
                   ckfa  ckposs+(1es[0ps+(1 0]);
            ++   ckpos 0]);
               tefa  ckpos]o i] =+i)
              else --a  ckposm[2] >0]);
            ++   tefa  ckpos]ig         =+i)
  s */
lse p , astoresg        *p , astore = m/* c, 256);
    retresulcbuf];tic k_t  /on lt8g(o_t usee**kd3,a{
  i0,a{
  i1,a{
  i2 ++z) {
    kcolor k;1       > 0)
di0,ai1,aa2);z) {
lse ad3_gfi[n */
 )2) {
    kd3_gfi[n */
   k    if     retkd3r /on lt[0][n */
 ed(o_t,
&k,1NULL)ata);

}


pt->colorfs->i_pos_era, (    ssedIreami,
nst 8nt
*new_ous_dx)",
                     ;
  Gie_coloreold cmFrx_t usee**kd3,x)",
                     /ay(32nt *h - Histolags)
{
  np->r (old cmrmap->n
;
;
  Gie_c *p->r (old cmrmp->n
;
    mapou56.;()  
  pnt i, j 
   y, transparencur_gfi->transpaight;    /* fcion ltsth6 coenurnewtsed colorels *    for (i = 0< ip->n2ol; > 1) {
  mapoieyen p->co.[i].pi=mk_t  /on lt8g(o_t, ap->co.a)c_rsi,iap->co.a)c_g, sca ap->co.a)c_blue    if   ap->co.has[P].pi=(1 0])}ght;   olorthe i els *    for (j = 0; cur_gfi->heigjl; > 1) {
nst 8nt
*ser_datcur_gfi-[jey, z;
    for (i = 0; h = gfi->wi2ol;saser_l;sanew_ous_l; i++)
  lse *ser_d!=  y, transpa ++z) {
    *new_ous_ = mapo8_t *i][j];
    h - Histo[*new_ous_]++][j];
  }


}2}l"
#d fine DITHER_SCALE;
  1024
#d fine DITHER_SHIFT;
  10
#d fine DITHER_SCALE_M1 (DITHER_SCALE-1)0#d fine DITHER_ITEM2ERR (1<<(DITHER_SHIFT-7))0#d fine N_RANDOM_VALUES 512;

}


pt->colorfs->i_floydasteinberg(    ssedIreami,
nst 8nt
*d 2_new_ous_dx)",
                           ;
  Gie_coloreold cmFrx_t usee**kd3,x)",
                           /ay(32nt *h - Histolags)
    static32nt *y, dom_put val[j0un, j 
  fi->wi= h = gfi->wi, j 
  pyk ei_py correct i] =+i 
   y, transparencur_gfi->transpaig;
    int ,tke ;
     kco*errbu*err1ight;   Iet i(fina   , aferssary *    for (i = 0; old cmrmap->n256; ++d) {
  ;
  Gie_c*vcdat&old cmrmp->rinnf      c->[i].pi=mk_t  /on lt8g(o_t, a->a)c_rsi,ia->a)c_g, sca a->a)c_blue    if   a_gfas[P].pi=(1 0])}ght;   
   Trce cwme The writall wre differency pmand q by J faPoskanzerag is   if  art in tbmplule ickt ima11) */   Iet i(fina Floyd-Steinberg tal_e vectorstent be smy, domnput vastic,w i++)
  /* doge snotifacts on(ve (top p w ary *talo 1] = Gif_NewArw    kc,
fi->wi+ 2);z) err1o 1] = Gif_NewArw    kc,
fi->wi+ 2);z)    Uce(ve (samemy, domnput va on(for ece smia nd a wrmpe entm/*noptii++)
 "jum mapppyk eimap" e<0dcts ma ndimformastary *lse !y, dom_put vaei++) {
 , dom_put val[j] = Gif_NewAripa32ntreN_RANDOM_VALUESIe pi;
    for (i = 0<iN_RANDOM_VALUES col; i++)
   , dom_put vaoieyenRANDOM( + 1(DITHER_SCALE_M1 * 2)a-iDITHER_SCALE_M1 0])}g;
    for (i = 0; h = gfi->wi+ 2n2ol; > 1) {
j [j] i+ if (gfef (ama)e pi;
    fkr (i =k0<d != 3k f++)
    err>col  k]  i , dom_put vao for+ k +% N_RANDOM_VALUES ] 0])}g;
   err1oset i(finad bel w ary
;
od3rbuild_xradius(o_t)ight;   Dor in the i! els *    for (j = 0; cur_gfi->heigjl; > 1) {
 
  pintd1, d2, d !=========    pres    fal_e d <0usrma     */
nst 8nt
*ser_, *new_ous_ 2.2;
    x; s */
lse p k ei_py correc ++d) {
  indefi->wi-(1 0]);
  d0r (intd1amma, d2  (1sad3 =*] =+i)
    } else {
  xo i] =+i)
  d0r (2ntd1amm0, d2  (1sad3 =*2gfi);
  )
  dus_ = &cur_gfi-[je[ie = 0;
new_ous_ = d 2_new_ous_r+ jidth = (unsignfi->wi+ x[2s */
    for (i = 0; fi->wi+ 2n2ol; 
)
    err1>col  x.a[jerr1>col  1.a[jerr1>col  2.a[j0un, j;
   Dora cemodoue w ary *;
    whixs[2] o   x0; fi->w ++d) {
      eig) {
      kco pright;

     rie the transparent c nens oge s ad we  enary */
  lse *ser_d==  y, transpa f++)
    goentnextight;

      /* fdesiif unewtsed cnary */
         > 0 pr,(old cmrmp->o8_t *i.a)c_rsi,iold cmrmp->o8_t *i.a)c_g, scax)",
           old cmrmp->o8_t *i.a)c_blue    if   lse ad3_gfi[n */
 )2) {
      kd3_gfi[n */
    pr    if       pr Floyd-Steinberg tal_estentad we jary */
      fkr (i =k0<d != 3k ++z) {
          vixe prl  k]x)",
          + (err>x+1ol  k] & ~(DITHER_ITEM2ERR-1) >/ DITHER_ITEM2ERR =+i)
       prl  k]ixeKC_CLAMPV(vs[2]);


  ht;

  er (old cmrmp->o8_t *i.[i].p;  */
  lse ar*  , afer(&od3_gks[e],
& pr s< ad3_gxradius>ee)ata)
      *new_ous_ = eig) {
      i++)
      *new_ous_ = kd3r /on lt[0][n */
 ed(o_t,
& pr,(NULL)at      h - Histo[*new_ous_]++][  if      ce c rete nds propag crefie fal_e nce betwdesiif unap aelcorf used c.i++)
     Assum ures ,tall wa     lascale (1024), now /* dopt->tentworry abouti++)
     the i notifacts caustd by fal_e  c um retrma ( uey actpplinghani++)
     fal_e _ermstm/pyrinot sumppal to fal_e).jary */
      fkr (i =k0<d != 3k ++z) {
      es[1rrprl  k]i-
od3_gks[*new_ous_]   k]ridtDITHER_ITEM2ERR =+i)
      lse e ++z) {
          talo>x+d0ol  k] +un((Ire] )0& ~15 >/ 16 0]);
          err1>x+d1ol  k] +un((Ire]3)0& ~15 >/ 16 0]);
          err1>x+d2ol  k] +un((Ire]5)0& ~15 >/ 16 0]);
          err1>x+d3ol  k] +un( essssss& ~15 >/ 16 0]);
      }2]);


  ht;

 next:  */
  lse p k ei_py correc 0]);
    x--saser_--sanew_ous_--nf++)
      i++)
    xl;saser_l;sanew_ous_l;gfi);
  )
     Dc va cemodoue w ary )
      /* chapyk eimap py correcssels */
+z) {
       kco*wrmpa[jerr1nf++)
   rr1o 1 rrnf++)
   rro 1wrmp =+i)
  dyk ei_py correct i!dyk ei_py correcgfi);
  )
}ght;   dif_De1wrmposew, store i els *;
  Gif_DeleteAr rr);s *;
  Gif_DeleteAr rr1data); id) d fa
   stmodaelcor_planite > 1) {
nst 8nt
plan[32];
nst 16nt
fracata odaelcor_planite 67
};

static*rordmequid k ei_lu 67
};

static vplan_ata _cplan(nst 8nt16plan,a{
  nplan,x)",
                         on coodaelcor_planite    p,a{
  n p,a{
  wholesma() {
 
  pntcfrac_subtamm0, planposmen0, ondrplanpose pi;
    for (i = 0; in pn256; ++d) {
    cfrac_subtaED] p i.. racat        endrplanposyen frac_subta* nplan>/ wholeat            whiplanposy; iendrplanpos)0]);
         lan[planpos++eyen p i..plan[32];
  )
      assplanposye= nplan)re}di    static ordmequid k ei_plan_ to com( on co
}

* x_da on co
}

* xb ++y) {
 on const 8nt16assed on const 8nt1) x_;y) {
 on const 8nt16bssed on const 8nt1) xb;z) {
lse ordmequid k ei_lu [*a]0; iordmequid k ei_lu [*b])2]);
        reiordmequid k ei_lu [*a] -iordmequid k ei_lu [*b];z) {
    i++)
        rei*_ -K*bre}di    static kc_liner /on lt( on cooire_c* p0,a on cooire_c* p1,x)",
                        on cooire_c* refthpe, do  r, /
  unsi*1p ,  ++y) {
     kcop01a p0refor k;1    kcoonline[2]);
/
  unsigd nn      
  pe pi;
    fd [i]  d0; i3n256d ++d) {
    p01l  des[0p1   xd.a-ip0   xd.56         0refl  des[0ref   xd.a-ip0   xd.56      )
  d ns[1h = (unsig6        (p01l  0]*p01l  0]s+(p01l  1]*p01l  1]s+(p01l  2]*p01l  2]);z) {
lse d ns[ i0)2]);
        rei] =+i)
   NB: We'voueun are of bitsmorep coisrma. We can>ce c rete hani++)
   d nominatorpin
/
  unsigaalgore stages, ver aum oat ctm/pyri++)
   ill ig civr,(oryitom/pyriillso     laplingif is
/
  unsi.i++)
   Ce c rete han aum oat cta  a
pe, do.jary */
* s[1rhpe, do)ep01l  0]*p0refl  0]s+(p01l  1]*p0refl  1]x)",
      +(p01l  2]*p0refl  2]) / i nn      se *c <e >sed*t 0)1)0]);
        rei] =+i)
    fd [i]  d0; i3n256d ++d) {
        vixe] = (int01l  des*d*t) +(p0   xd.56        onlinel  des[0KC_CLAMPV(vs[2]);
  )
  *p , s[1ar*  , afer(&online, eqf 256);
    ret1re}di    static kc_planer /on lt( on cooire_c* p0,a on cooire_c* p1,x)",
                       a on cooire_c* p2,a on cooire_c* reftx)",
                       ape, do  r, /
  unsi*1p ,  ++y) {
     kcop0refthp01a p02gfi);
pe, doun[3.a pvec[3.a dec
dqvec[3.a u, vn      
  pe =+i)
   Ce c rete han aon-unit aorm(l  rt in tlane decermined by  in tnputi++)
   th6 coent0-p2)sary */
    fd [i]  d0; i3n256d ++d) {
    p0refl  des[0ref   xd.a-ip0   xd.56        p01l  des[0p1   xd.a-ip0   xd.56         02l  des[0p2   xd.a-ip0   xd.56      )
  n[les[0p01l  1]*p02   2.a- p01l  2]*p02   1.re)
  n[1es[0p01l  2]*p02   0.a- p01l  0]*p02   2.re)
  n[2es[0p01l  0]*p02   1.a- p01l  1]*p02   0.e =+i)
   Moeller-Trumbore  wyxtracnothi(y algor:xtracerdl wyxata f`ref`hi(ong6       aorm(l `n`;a onvere entbew,centrstacoordinatestent ee hat ie  wy6        
    ects wll wrie thiamodo.jary */
pvec[les[0n 1]*p02   2.a- n 2]*p02   1.re)
  pvec[1es[0n 2]*p02   0.a- n 0]*p02   2.re)
  pvec[2es[0n 0]*p02   1.a- n 1]*p02   0.e =+i)
dec [ipvec[le*p01l  0]s+(pvec[1e*p01l  1]s+(pvec[2e*p01l  2]n      se fabp(dec)ocol0.0001220703125 >/*ro unoptir GIF wten mcnrerart iing    */
        rei] =+i)
dec [i1 / i tight;

uixe]p0refl  0]*pvec[les+ p0refl  1]*pvec[1es+ p0refl  2]*pvec[2]ridtdec 0]);
 se u <e >sedu 0)1)0]);
        rei] =0]);
qvec[les[0p0refl  1]*p01l  2]a- p0refl  2]*p01l  1];0]);
qvec[1es[0p0refl  2e*p01l  0]s- p0refl  0e*p01l  2]n     qvec[2es[0p0refl  0e*p01l  1]s- p0refl  1e*p01l  0] =0]);
vixe]n 0]*qvec[les+ n 1]*qvec[1es+ n 2]*qvec[2]ridtdec 0]);
 se v <e >sedv 0)1>sedu +dv 0)1)0]);
        rei] =0]);
   N w we kand at>ickrecostat;o 
  pnwrie thiamodoaplingisfcion cdat0]);
   `ref`hter t 1y ;o 
  i(ongfitsmedges. R   reirie bew,centrsti++)
   thordinatest    pling;o 
  igro ia   , aferppal ting;o 
 .jary */
t[les[0u;y */
t[1es[0vn     vixe]p02   0.*qvec[les+ p02   1.*qvec[1es+ p02   2.*qvec[2]ridtdec 0]);
* c, s[1rr= (unsign v * v * ]n 0]*n[les+ n 1]*n[1es+ n 2]*n[2]ri+(i.5 256);
    ret1re}di    static vlnopt_ordmequid k ei_plan(nst 8nt16plan,a{
  nplan,a{
  n ,x)",
                           ++)
   thn cooire_c* wannFrx_t usee**kd3 > 1) {
n
  unsigm/* c, ,1d st[2]);
{
  n pmen0, nb lt pmen0, int ,tke ;
;
pe, dout 2]n     odaelcor_planite >cpou56.age lt p[16.re)
  ncdatncdcol16 ?tncd: 16 00]);
   aort th6 col    */
 p[0..plans[0plan[ley, z;
 p[0..fraci=(1 0])/
    fn pmenor (1 = 0!= nplan;= 2; ++i)
        plan[ii-(1]o 1]plan[ies2) {
        ++ p[n pm-(1]. racat        e } else {
         p[n p..plans[0plan[i.> 7);








 p[n p..fraci=(1 0])/
        ++n pn0])/
        }

   ce c rete plansels */
 /* c, s[1rr= (unsign-1[2])/
    for (i = 0; in pn256; ++d) {
        /ecktion tion ltscemodouth6 cd    */
    p , s[1ar*  , afer(&od3_gks[ p i..plan.agwann) =+i)
        d stx< m/* c,  ++z) {
        e lt p[0..plans[0 p i..plan[32];
        e lt p[0..fraci=(KC_WHOLE[32];
        nb lt pmen1 0])/
        minpy, s[1d st[2]);




  ht;

  

    for (is+(1 =ncdnd]     j0< ipp;= 2; ++j) {
            /ecktion tion ltsblond art wosth6 col    */
        lse ar*liner /on lt(&od3_gks[ p i..plan.ax)",
                           +&od3_gks[ p j..plan.ax)",
                           +wannFr&t(x., &py, o[j];
           +&& d stx< m/* c,  ++z) {
            e lt p[0..plans[0 p i..plan[32];
            e lt p[1..plans[0 p j..plan[32];
            e lt p[1..fraci=(] = (inKC_WHOLE * toles[0]);
            e lt p[0..fraci=(KC_WHOLEa- b lt p[1..frac[0]);
            nb lt pmen2[0]);
            minpy, s[1d st[2]);








}f 0;  t;

  

    fkr (js+(1 =ncdnd]3o   a0< ipp;= 2k f++)
                /ecktion tion ltsblond art hieesth6 col    */
            lse ar*planer /on lt(&od3_gks[ p i..plan.ax)",
                           ++++++&od3_gks[ p j..plan.ax)",
                           ++++++&od3_gks[ p k..plan.ax)",
                           ++++++wannFr&t(x., &py, o[j];
           +++++&& d stx< m/* c,  ++z) {
                e lt p[0..plans[0 p i..plan[32];
                e lt p[1..plans[0 p j..plan[32];
                e lt p[1..fraci=(] = (inKC_WHOLE * toles[0]);
                e lt p[2..plans[0 p k..plan[32];
                e lt p[2..fraci=(] = (inKC_WHOLE * to1es[0]);
                e lt p[0..fraci=(KC_WHOLEa- b lt p[1..fraca- b lt p[2..frac[0]);
                nb lt pmen3[0]);
                minpy, s[1d st[2]);












    }
    }2    }2e)
  plan_ata _cplan(plan,anplan,ab lt p, nb lt p,(KC_WHOLE)re}di    static vset_ordmequid k ei_plan(nst 8nt16plan,a{
  nplan,a{
  n ,x)",
                           ++)
 ;
  Gie_c*vgfcFrx_t usee**kd3 > 1) {
    kcowannFrcurnf++)
     kco rrnf++)
 
  pntd 2y */
oi     > 0wannFrgfc->a)c_rsi,igfc->a)c_g, sca gfc->a)c_blue    if lse ad3_gfi[n */
 )2) {
    kd3_gfi[n */
   wann) =f++)
     /* r(& rr);s */
    for (i = 0; inplan;= 2; ma() {
        fd [i]  d0; i3n256d ++d) {
    ++)
 
  vixewannl  des+o rr. xd.56            curl  des[0KC_CLAMPV(vs[2]);




    }
    plan[i. = kd3r /on lt[0][n */
 ed(o_t,
&cur,(NULL)at            fd [i]  d0; i3n256d 6             rr. xd.aED]wannl  des-
od3_gks[plan[i.]. xd.56           q /* (plan,anplan,a1, ordmequid k ei_plan_ to com); s */
lse ncdc nplan>   [lan[le !e plan[nplan-1] ++d) {
        n pmen1 0])/
        for (1 = 0!= nplan;= 2; ++i)
        n pm+[0plan[i-1] !e plan[innf            n pm> n  ++i)
        lnopt_ordmequid k ei_plan(plan,anplan,anc N&wannFrx_t_gfi);
    }

gfc->fas[P].pi=(1 0}di    static vpow2_ordmequid k ei(    ssedI*vgfi,
nst 8nt* d 2_new_ous_dx)",
                           o;
  Gie_colo*told cmFrx_t usee**kd3,x)",
                            /ay(32nt* h - Histo,
 on const 8nt16matrsx,x)",
                            /ay(8nt16plansma() {
 
  mws,anplans, intx, y;s */
    fmws [i]  (1 << mws) !e matrsx[ley ++mws)0]);
       nimahin = 0;
    fnplans [i]  (1 << nplans) !e matrsx[2ey ++nplans)0]);
       nimahin == 0;
    fy [i]  y !e cur_gfi->heig++y ++d) {
    nst 8nt
*ser_, *new_ous_, * in plan[32];
    ser_datcur_gfi-[ynnf        new_ous_ = d 2_new_ous_r+ yidth = (unsignh = gfi->wi,0])/
        fxo i]  x !e cur_gfi->wi2++x)f++)
           rie the transparent c nens oge s ad we  enary */
            dus_[x] !e cur_g y, transpa ++z) {
             in plan = &plan[dus_[x] << nplans.> 7);












    !old cmrmp->odus_[x]o.has[P].p>0]);
                 et_ordmequid k ei_plan( in plan892d<< nplans, matrsx[3.ax)",
                           +++++++++++++&old cmrmp->odus_[x]oFrx_t_gfi);












  e matrsx[4 +  ixi+ if (gfef (a&th  trsx[le -K) )ata)
            pi;
       +  ify + if (gtdp)s&th  trsx[1e -K) ) << mws).> 7);












new_ous_[ieye  in plan>i.> 7);












h - Histo[new_ous_[ie]++][j];
        }2    }2f];};

static vpt->colorfs->i_ordmequ(    ssedI*vgfi,
nst 8nt* d 2_new_ous_dx)",
                           o  o;
  Gie_colo*told cmFrx_t usee**kd3,x)",
                               /ay(32nt* h - Histo,x)",
                                on const 8nt16matrsxsma() {
 
  mw e matrsx[le, mh e matrsx[1],anplan e matrsx[2ey
    /ay(8nt16planl[j] = Gif_NewAr/ay(8nt,anplan * old cmrmap->)nf++)
 
  pntx, y;s  }

   Whe writall wre differencyJo.piYlilouma's 
   von . ary )
     Iet i(fina th6 col    */
    for (i = 0; iold cmrmap->n256; x)",
    old cmrmp->rin.has[P].pi=(] =0]);
   Iet i(fina luminafers,     creluminaferekd3_ere    */
ordmequid k ei_lu l[j] = Gif_NewAriparead3_gnite sIe pi;
    for (i = 0; iad3_gnite s;= 2; ++i)
    ordmequid k ei_lu [co  iar_luminaferfood3_gks[i])un, j;
   Dor in the i! els *

    fmws&th w -K) ) =2] o   (mh   (mh -K) ) =2] ++i)
       (nplan>  (nplan>-K) ) =2]  ++i)
    pow2_ordmequid k ei(gfi,
d 2_new_ous_dtold cmFrx_t, h - Histo,x)",
                        matrsx, plan)re        i++)
        fy [i]  y !e cur_gfi->heig++y ++d) {
        /ay(8nt
*ser_, *new_ous_, * in plan[32];
        ser_datcur_gfi-[ynnf            new_ous_ = d 2_new_ous_r+ yidth = (unsignh = gfi->wi,0])/
            fxo i]  x !e cur_gfi->wi2++x)f++)
         j;
   rie the transparent c nens oge s ad we  enary */
         *

    dus_[x] !e cur_g y, transpa ++z) {
                 in plan = &plan[nplan * ous_[ie][0]);
                    !old cmrmp->odus_[x]o.has[P].p>0]);
                     et_ordmequid k ei_plan( in plan89nplan,amatrsx[3.ax)",
                           +++++++++++++++++&old cmrmp->odus_[x]oFrx_t_gfi);












      e matrsx[4 +  xi+ if (gfef (a% mwx)",
                           +  iy + if (gtdp)s% mhridtmw][0]);
                new_ous_[ieye  in plan>i.> 7);
















h - Histo[new_ous_[ie]++][j];
                }
        }

   dif_De1wrmposew, store i els * *;
  Gif_DeleteArordmequid k ei_lu ount);
;
  Gif_DeleteArplan)re}di;};

static vd k ei(    ssedI*vgfi,
nst 8nt* new_ous_, ;
  Gie_colo*told cmF 7);















o_t usee**kd3,a/ay(32nt* h - Histo,
tt_Outpuf_OptD odei++) {
lse od opyk ei_&& (t=pepyk ei_defaulti++)
    ||emd opyk ei_&& (t=pepyk ei_floydasteinbergla         t->colorfs->i_floydasteinberg(gfi,
new_ous_dtold cmFrx_t, h - Histo)re        
lse od opyk ei_&& (t=pepyk ei_ordmequ 7);









||emd opyk ei_&& (t=pepyk ei_ordmequinewla         t->colorfs->i_ordmequ(gfi,
new_ous_dtold cmFrx_t, h - Histoax)",
                           md opyk ei_ous_)re        i++)
    pt->colorfs->i_pos_era, (gfi,
new_ous_dtold cmFrx_t, h - Histo)re};
}

    retput v92dmeans eun  ia   pe otagainhini    static
try_as  un use_transpar(    ssedIreami,
;
  Gie_coloreold cmFrnst 8nt
*new_ous_dx)",
                    ;
  Gie_colorenew_cm,a{
  enew_ap->dx)",
                    o_t usee**kd3,a/ay(32nt *h - Histolags)
/ay(32nt min_ustdre   
  pnt i, j 
   y, transparencur_gfi->transpaig      new_ y, transparen-1[2]);
  Gie_c  y, tr_put vun, j se  y, transpar<] >0]);
    rei] =0])lse old cm>0]);
 y, tr_put vr (old cmrmp->o y, transpa.> 7)    i++)
GIF_SETCOLOR(& y, tr_put v%d0,
0,
0s[2


   uld      an unupres[P].pipnwrie exic_imov te_colo;ep cf cdae (samem te_cx)",
 we hadsary *    for (i = 0; enew_ap->n2ol; 
)
  lse h - Histo[ieye[1 o   GIF_COLOREQ(& y, tr_put v%d&new_cmrmp->rin) ++z) {
  new_ y, transparen;data;
  goentfckgr56      )
    for (i = 0; enew_ap->n2ol; 
)
  lse h - Histo[ieye[1  ++z) {
  new_ y, transparen;data;
  goentfckgr56      
     trappalexpigro ia sed colorels * se *new_ap->s< 256 ++z) {
    ass*new_ap->s< new_cmrmpapacity)re    new_ y, transparenenew_ap->ne    new_cmrmap->iew_ y, transpaeye  y, tr_put vun    s*new_ap->)++][j];
goentfckgr56    
     not fckgr: markl to fiast-frequspaly-upresent c asmver ake  y, transpa

    pt->c igro    ret1  m a run '  pe otagain')sary *    ass*new_ap->s==i_t, 256)min_ustdr (ixFFFFFFFFU; )
    for (i = 0; ble_2ol; 
)
  lse h - Histo[iey<)min_ustd ++z) {
  new_ y, transparen;data;
  min_ustdr (h - Histo[ie56      )
o_t py,ma_t(o_t,
new_ y, transpa);;   olrklie as unupma_tsary *    ret1re
 fckgr:
 *    for (j = 0; cur_gfi->heigjl; > 1) {
nst 8nt
*ser_datcur_gfi-[jey, z;
    for (i = 0; h = gfi->wi2ol;saser_l;sanew_ous_l; i++)
  lse *ser_d==  y, transpa f++)
    *new_ous_ = new_ y, transpa56    
  cur_gfi->transpa = new_ y, transpa56      rei] =};

}


pt->colorsuseam(    Suseam*vgfs, ;
  Gie_colo*tnew_cm,att_Outpuf_OptD odeags)
o_t useeiad3;  };
  Gie_c *new_c->r (new_cmrmap-ig      new_nc->r (new_cmrmap->d(new_istyre   
  psedIpnt i, j 
   to ress_new_cmi=(1 0
t;   olk (sura sed colorame enough traere    *    new_cmrmpapacitys< 256 ++z) {
;
  Gie_c *xl[j] = Gif_NewAr;
  Gie_c,i_t, 256);
    py(x,
new_c->,ata, siz;
  Gie_cridtnew_ap->)unt);
;
  Gif_DeleteArnew_c->)ne    new_cmrmap-r (new_cp-r (xne    new_cmrmaapacitys[1ble_256}y *    assnew_cmrmaapacitys>=i_t, 25
     new_cp- j..pP].pi==mnuRememorepP].ps wll wpt->c jipnwrie ake psedI. els *    for (j = 0; ble_2jl; i++)
new_cp- j..pP].pi=i] =0])   set i(fina ad3efiee_*/56)new_istymen1 0])    for (j =new_istym   j0< iew_cmrmap-> 256; u 0;
+x    new_cp- j..a)c_rsi0!= new_cp- j..a)c_g, scx)",
      ||enew_cp- j..a)c_rsi0!= new_cp- j..a)c_blue x)",
      new_istymen] =+io_t set  build(&o_t,
new_istym?iar_luminafer[0][n */
  :(NULL,
new_cm 25
      fosedIpr (i = sedIpr; h s_gnis->im = sedIpl; > 1) {
    ssedIreamidatcus_gfi->im[ sedIp];z) {
;
  Gie_colorea)cmr_tif (gfocalm?iif (gfocalm:tcus_gfs->glnf++)
 
  ge (_ to resstdr ((cur_gfi-ye[1  ; s */
lse a)cmsma() {
;
   Ifpplkrecwa  an(old sed colo,  /* cha in the i ous_ ary */
  nst 8nt
*new_ous_l[j] = Gif_NewAr/ay(8nt,ah = (unsignh = gfi->width = (unsignh = ghi->hei256);
  /ay(32nt h - Histo[u56.;() ;
  /nolrkpare_cs(new_cm 25) ;
  /nolrkpare_cs(a)cmsi,0])/
  lse oe (_ to resstd x)",
      ] = Un to ressssedI(gfs, h =si,0])/
  o_t enma_t_d 2(&o_t 25) ;
  doma() {
        for (j = 0; ble_2jl; i++)








h - Histo[j]o i] =+i)
    d k ei(gfi,
new_ous_dta)cm,
&k_t, h - Histoa ode =+i)
  }     whitry_as  un use_transpar(gfi,
a)cm,
new_ous_dtnew_cm,a&new_ap->dx)",
                                   &k_t, h - Histo)si,0])/
  ;
  GifiaseUn to ressedssedI(gfi    if      
   von 1.28 bug fix:   fiaset 1y  to resstdr
   von oryit (itcaustx)",
      od fs->im ary */
  ;
  GifiaseCto ressedssedI(gfi    if       SetUn to ressedssedI(gfi,
new_ous_dt    Fiee,
0si,0])/
  lse oe (_ to resstd ata) {
        _NewFuo ressssedI(gfs, h =,a&g   The e sefoount);
t);
;
  GifiaseUn to ressedssedI(gfi    if   }f 0;  t;    pd crecau   of upresent cm ary */
      for (j = 0; ble_2jl; i++)




new_cp- j..pP].pi+=
h - Histo[j];0])/
  lse cur_gfi->transpa [2] >0]);
       now /* dohavi ous_ on(ve (nuRememoreupresent cm f_c  y, transparx)",
       sntfud i it.nary */
    new_cp- cur_gfi->transpa..pP].pi+=
h = (unsignh = gfi->width = (unsignh = ghi->he / 8i,0])/
    } else {
     Ce* do to resstnew_cm afterwards lsenow id* doaccivrly  /* chaent cmx)",
     ovecd    */
   to ress_new_cmi=(] =+i)
  s */
lse a) (gfocal ++d) {
  ;
  Gif_DeGie_colo a) (gfocal data;
  gf (gfocalm=(] =+i)
      
     Set iew_cmrmap->xata fnew_ap->. We  id* do pd creiew_cmrmap->xbefore ic++i)
  ia s/on lt-pt->c i(y algors would* do ee  1y ake  y, transpaaent cm.i++)
 Ttingwtymade en y, transpaaent cmenorerae (  pres     y, transpar._*/56)new_cmrmap->r (new_ap->ne
      /* charie beckgackgr. Iohatharie beckgackgr by n w ary *    fh s_gnis->im  1] >sedcus_gfi->im[0]_gfi->transpa <] >0]);
     cus_gfs->gl    cus_gbeckgackgr < cus_gfs->glrmap->)++d) {
  ;
  Gie_c *cdat&cus_gfs->glrmcp- cus_gbeckgackgr]data;
  gfs_gbeckgackgr =mk_t  /on lt8g(&o_t, a->a)c_rsi,ia->a)c_g, sca a->a)c_blue    if   new_cp- cus_gbeckgackgr].pP].p++][j]      else h s_gnis->im > x7F80cus_gfi->im[0]_gfi->transpa [2] >0]);
  gfs_gbeckgackgr =mcus_gfi->im[0]_gfi->transpa> 7)    i++)
  gfs_gbeckgackgr =m] =0]);
  Gif_DeGie_colo a)s_gfs->gl) =+io_t  /* cle(&o_t)ight;   We mtymhavi upresma ( a(subsec  rt in ch6 coenurnew_cm. We trappalstorei++)
 ma (  tingsubsecnt we jas lseno'es[Ppero ia outpuf  rt'g  si /*i++)
 --upr-sed colo=X't hiough 'g  si /*'  1ope otext ._*/56)cus_gfs->gl = ;
  GipyGie_colo new_cm 25)     for (j = 0; iew_cmrmap-> 256; u 0;
+xcus_gfs->glrmcp- jn.has[P].pi=(] = *     to ress_new_cm)++d) {
/*roa ( bope oteo recto resstlseno'(itge snnythemoviuf  rtifxels */
 to ress_new_cmi=(] =+i)
    for (j = 0; iew_cmrmap->i-(1 2jl; i++)


    new_cp- j..pP].pi==m0 ||enew_cp- j..pP].pi<enew_cp- j+1ol[P].p>= 0) {
     oo ress_new_cmi=(1 0) {
    break   if   }f    
       to ress_new_cm)++d) {
    mapou56.;(d) {
/*r;
  GipyGie_coloecaniesmver '[P].p'nput va 
  no(it    */
new_cp-r (cus_gfs->glrmcp- =+i)
    for (j = 0; iew_cmrmap-> 2jl; i++)


new_cp- j..has[P].pi=(j 00]);
   aort bapresma pop regitys    */
q /* (new_c->,anew_cmrmap->d(ta, siz;
  Gie_cr, pop regityrkd3_u to com); s */
   aedo pmver oloeigro  duce(ve (nuRememoreth6 col    */
    for (j = 0; iew_cmrmap-> 2jl; i++)


mapo
new_cp- j..has[P].pi]i=(j 0 */
    for (j = 0; iew_cmrmap-> 2jl; i++)


    !new_cp- j..pP].p>= 0) {
    cus_gfs->glrmap->i=(j 0 */
    break   if   }fs */
   oloe in the i ous_,  y, transpairs, igrobeckgackgr els *

    cus_gbeckgackgr < cus_gfs->glrmap->)0) {
    cus_gbeckgackgr =mmapocus_gbeckgackgr]data;
    fosedIpr (i = sedIpr; h s_gnis->im = sedIpl; > 1) {
{
    ssedIreamidatcus_gfi->im[ sedIp];z) {
)
 
  ge (_ to resstdr ((cur_gfi-ye[1  ; ) {
)
/ay(32nt ta, ; ) {
)
/ay(8nt
*ser_;0])/
  lse oe (_ to resstd x)",
      ] = Un to ressssedI(gfs, h =si,0])/
  ser_datcur_gfi->i_ser_;0])/
      fta,  =
h = (unsignh = gfi->width = (unsignh = ghi->he; ta,  > x; ta, --saser_l; i++)




*ser_datmapo8_t *i][j];
  lse cur_gfi->transpa [2] >0]);
    cur_gfi->transpa = mapocur_gfi->transpa.i,0])/
  lse oe (_ to resstd ata) {
        _NewFuo ressssedI(gfs, h =,a&g   The e sefoount);
t);
;
  GifiaseUn to ressedssedI(gfi    if   }ff   }ff }ta);
}
 Halftone i(y algors N
 **/  sta on const 8ntepyk ei_matrsx_o3x3[4 + 3*3]i=(ta) {
t, t, 9, 9,a) {
2, 6, t,a) {
5,
0,
8,a) {
1, 7, 42767
};

sta on const 8ntepyk ei_matrsx_o4x4[4 + 4*4]i=(ta) {
4,
4,
16,
16,  if  0,

8,{
t, 10,a) {
12, 
4,
14,
 6,  if  2, 11, 
1,  9,a) {
15,
 7, 1t,  52767
};

sta on const 8ntepyk ei_matrsx_o8x8[4 + 8*8]i=(ta) {
8,
8, 64, 64,  if  0,
48, 12, 60,{
t, 51, 15,
6t,a) {
32,
16,
44, 28, 35,
19, 47, 31,x)",
 8, 56, 
4,
52, 11, 59,
 7, 55,x)",
40,{24,
36, 20,
4t, 27, 39,
23,  if  2, 50,
14,
62, 
1, 49, 1t, 61,x)",
34,
18, 46, t0,
3t, 17, 45,
29,a) {
10,
58,
 6, 54,  9, 57,{
5,
53,  if 42, 26, t8,
22, 41,i_t, t7,{212767
};

sta on const 8ntepyk ei_matrsx_ro64x64[4 + 64*64]i=(ta) {
64, 64,
16,
16,  if  6, 15,
 2, 15,
 2, 14, 
1, 1t,  2, 14, 
5, 1t,  0,
14,
 0,

9,
 6, 10,
 7, 1t,  6, 1t,  3, 10,
 5, 15,
 4, 11, 
0, 11, 
6, 10,
 7, 12,
 7, 1t,  0,

9,
 6, 15, 
6, 10,
 0, 15, 
1, 15,
 0,

8,{
0, 15, 
6, 15,
 7, 15,
 7, 
9,
 1, 15,
 3,

8,{
1,

8,{
0, 14,  if  9,  3, 10,
 5, 10, 
6, 10,
 5,

9,
 6, 
9,
 2, 
9,
 4, 1t,  4, 1t,  3, 
8,{
t, 10, 
1, 1t,  6, 11, 
1, 12,
 3, 14, 
5, 15,  3, 
8,{
t, 
8,{
t, 12, 
4,
11,{
t, 1t,  3, 
8,{
4,

9,
 6, 12, 
4,
11,{
6,
11,{
t, 10,
 0, 12, 
1, 11,{
7, 12, 
4,
12, 
4,
11,{
5,x)",

1, 14,
 0,
10,
 2, 
9,
 2, 11, 
1,  8,{
1,

8,{
3, 
9,
 4, 15,
 7, 1t,  7, 14,
 7, 14,
 0,
10,
 0, 14,
 7, 
9,
 0, 11, 
1, 15,
 0, 11, 
0,
11,{
t, 15,
 7, 14,
 6, 10,
 5,

8,
 0, 11, 
0,

8,
 7, 11, 
0,
15,
 0, 12, 
1, 13,
 6, 
9,
 0,
15,
 4,

9,
 1,

8,a) {
10,

5, 15,  6, 13,
 6, 14,
 7, 14,
 4,
12, 
5, 15,  6, 10,
 2, 11, 
t, 10,
 3,
11,{
t, 1t,  6,
11,{
5, 14,
 3, 14,
 6, 
8,
 5, 14,
 5, 14,
 7, 10,
 7, 11, 
t, 1t,  3, 1t,  2, 14, 
4, 15,
 5, 15,  3, 
8,{
4,
11,{
4,

9,
 5, 12,
 3, 
8,
 5, 15,
 2, 13,{
5,x)",

3,
10,
 2, 
9,
 5,
15,
 4,

9,
 0, 11, 
7, 11, 
0,
14,
 5, 11,
 5, 14,
 7, 15,
 6, 
9,
 0,

9,
 0,

8,{
4,
14,
 6, 12,
 0, 11, 
4, 15,
 5,  8,  6, 10,
 6,
11,{
6, 10,
 t, 12, 
5,

9,
 6, 
9,
 5, 12,
 6, 12,
 7, 14,
 0,
14,
 2, 15,
 5,  8,  2, 10,
 t,  9,a) {
14,
 7, 14,
 7,  8,{
1,
12,
 2, 14, 
4, 15,
 3, 11,
 5, 12,
 2, 
8,
 0, 10,
 t, 12, 
1, 13,{
5,
14,
 5, 11,
 0,
11,{
t, 13,
 7,  8,{
1,
12,
 3, 15,
 3, 14,
 2, 15,
 3,
11,{
6, 15,{
1,
12,
 1,  9,  3,  9,  3, 11,  3, 11,  7, 11,
 5, 12,
 0,
14,
 6, 13,
 6,x)",

5, 10, 
6, 12,
 3, 15,
 3, 
8,
 7, 10,
 0, 15, 
7, 10,
 5,  8,{
1,
14,
 5, 10,
 7, 14,
 2, 14,
 0,
14,
 1,

8,{
3, 
8,
 5, 10,
 5,
15,
 0,

8,{
6, 14,
 0,
 8,  2, 15,
 4, 11, 
6, 10,
 0, 
8,
 5, 
9,
 4, 14, 
1, 15,
 3,
10, 
1, 15,
 0, 15,
 5,  8,  7, 1t,a) {
15,
 3, 
8,
 0,

9,
 6, 12,
 6, 15,
 0, 11, 
4, 14, 
3, 15,
 3,
10, 
5, 12,
 3, 10,
 t,  9,
 6, 
9,
 5, 13,{
5,
15,  6, 14,
 0,

9,
 0, 12, 
4,
11,{
t, 15,
 4, 11, 
6, 15,
 2, 15,
 3, 14,
 4, 1t,  2, 11, 
1,  8,{
5, 12,
 7, 
9,
 4,  8,{
5, 12,
 2, 11, 
0,  if  0,
13,{
5,
11,
 5, 14,
 5,
15,  7, 
9,
 5,  8,  2, 10,
 t, 15,
 6, 
9,
 t, 12, 
5,
11, 
6, 14, 
3, 1t,  6, 1t,  0,

9,
 1,
11,{
t, 
8,{
3, 
9,
 4, 
9,
 6, 14,
 7,  8,{
6, 12,
 7, 13,
 6, 
9,
 5, 13,{
t, 15,
 5, 14,
 3, 15,
 4, 12, 
4,
12, 
2, 1t,  0,
15,a) {
10,

7, 14,
 1,  8,{
2, 10,
 2, 12,
 0,
13, 
1, 13,{
5,
11, 
6, 12,
 3, 
9,
 6, 15, 
1,  9,  1, 10, 
6, 10,
 t, 15,
 6, 15,
 5, 15,  7, 12, 
6, 12,
 0, 
9,
 t, 12, 
3,
11,{
t, 
8,{
3, 1t,  2,  9,  3,  9,  6, 10,
 2, 11, 
6, 
9,
 0,

9,
 1,  9,  6, 10,
 4,x)",

3,
10,
 4, 
9,
 4, 
9,
 6, 13,{
t, 15,
 0,

8,{
4,
10,
 0, 14,
 5, 15,  7, 15,
 2, 12,
 7, 10,
 5, 15,  7, 
8,
 0,

9,
 0,

8,{
6, 14,
 4, 15,
 2, 15,
 1, 15,
 0,

9,
 5, 14,
 0,
12,
 7, 10,
 6,

8,{
6, 11,
 0,
1t,  7, 14,
 1, 1t,  2, 10,
 5,

9,
 0, 14,  if 14,
 6, 13,
 1,
12,
 3, 
8,{
3, 
9,
 6, 12, 
4,
15,
 2, 
8,
 5, 
9,
 1, 10, 
1,  8,{
5, 15,
 0,

8,{
2,
12,
 3, 12, 
5,
12, 
5,
11, 
2, 10,
 2, 
8,
 5, 10,
 5,
12,
 4, 
9,
 3, 
8,{
4,
13,
 1,
15,
 0, 12, 
3, 
8,{
4,
10,
 t,  9,
 5, 13,{
5,
13,{
t, 11,
 4,x)",

4, 12,
 3, 10,
 6, 
9,
 0,
14,
 0,
 8,  1,  9,  1, 
9,
 6, 15, 
0,
10,
 2, 
9,
 6, 10,
 7, 10,
 2, 14,
 4, 
8,
 0, 13,
 4, 
8,
 1,
11,{
6, 14,
 7, 14,
 0,

8,{
4,
14,
 7, 14,
 4,

9,
 2, 12,
 0,
12,
 3, 
8,
 5, 
9,
 6, 14,
 0,

9,
 2, 14,
 5, 10,
 1,
15,a) {
10,

2, 15,
 6, 14, 
3, 11, 
6, 15,
 4, 15,
 4, 13,{
5,
11, 
t, 12, 
4,
14,
 5, 12,
 0,
13, 
3, 
8,
 6, 15,
 2, 10, 
6, 13,
 2, 12,
 6,

8,{
t, 10,
 3,
14,
 5, 
8,
 0, 10,
 t, 1t,  2,  9,  6, 10,
 6,
15,
 4, 13,{
2,

8,{
t, 14,
 6, 11,  7, 13,
 0, 10,
 5,  if  2, 13,  1, 
9,
 5, 10,
 t, 15,
 6, 10,
 0, 15, 
4, 15, 
4, 15, 
6, 
9,
 0,
14,
 1, 
9,
 6, 12,
 0, 11, 
5, 
9,
 0,
14,
 5, 14,
 6,  9,  3, 11,  7, 11,
 1,
15,
 1,  9,  3, 13,{
5,
12,
 0, 
9,
 2,  9,  6, 1t,  2,  9,  6, 13,  7, 11,
 7, 
8,
 0,
13, 
3, 
9,  if  9,  6, 13,
 6, 1t,  0,

8,
 5, 14,
 2, 11,  7, 11,
 2, 11,
 2, 12, 
3,
11,{
4, 1t,  4, 10,
 t, 15,
 5, 1t,  0,
11, 
6, 10,
 0, 13,{
t, 15,
 7, 14,
 3, 
8,{
4,
12,
 6,

9,  6, 10,
 3, 14, 
5, 13,{
5,
11, 
t, 13,
 6, 
8,{
2,
14, 
3, 15,
 3,
11,{
4,
12,
 6,x)",

4, 10,
 7, 11, 
1, 10, 
2,
14, 
7, 14,
 0,
14,
 4, 15, 
0,

8,
 0, 15,
 5, 15,
 7, 11, 
7, 14,
 6, 12,
 0, 
8,
 1,
15,
 1, 14,{
2,

8,{
0, 11, 
4, 
8,
 5, 11, 
1, 15,
 0, 12,
 7, 14,
 0,
11, 
4, 
8,
 2,

8,{
0, 14,
 2, 14,
 4, 
9,
 4, 10,
 7, 15,
 5, 14,  if 14,
 0, 13,{
2, 14,
 5, 11,
 5, 10, 
2,
10,
 6,
11,{
t, 12, 
5,
11, 
7, 11, 
1, 12, 
3,
11,{
t, 
9,
 t, 12, 
4, 11, 
6, 
9,
 5, 14,
 5, 12,
 7, 14,
 2, 12, 
1,  8,{
4,
11, 
7, 10,
 3, 14, 
4, 14,
 0,
14,
 5,
11, 
7, 11, 
5, 15,
 1, 14,
 0,
10,
 t, 10,
 0,x)",

5, 12,
 7, 10,
 7, 11, 
0,
14,
 5, 14,
 1, 14,
 3, 
8,
 0,
15,
 0,

9,
 5, 
9,
 1,

8,
 6, 15, 
6, 15,
 7, 13,
 7,  9,{
4,
11, 
0,
10,
 6, 10,
 7, 12,
 7, 15,
 0,

9,
 7, 14,
 2, 11, 
0,
12,
 7, 11, 
7, 1t,  0,

9,
 6, 14,
 2, 11, 
1, 15,
 0,

8,
 0, 10,a) {
10,

3, 15,
 3,
15,
 3, 
8,
 4,
11,{
t, 11,
 6, 15, 
6, 11,
 5, 12,
 5, 1t,  0,
15,
 4, 
8,
 1,
11,{
t, 10,
 3,
15,
 3, 14,
 1, 14,
 6, 13,{
t, 11,{
t, 11,{
t, 13,
 6, 
8,{
t, 12, 
5,

8,{
4,
13,
 3, 
8,
 2, 13,  4,

8,{
t, 14,
 7, 
8,
 5, 14,
 4, 15,
 5,x)",

3,

9,
 0,
10,
 0, 12, 
3,
11,{
7, 10,
 6,

8,{
7, 12,
 0, 11, 
1,  8,{
5, 12,
 5, 12,
 7, 11,
 2, 14,
 0,
10,
 0, 12, 
0,
15,
 2, 
9,
 5,

9,
 0,
15,
 4,
14,
 6,  9,  7, 11,
 6, 10,
 0, 
9,  1, 
9,
 0,
14,
 4, 12, 
5,

9,
 6, 10,
 4, 11, 
6, 12,
 5, 12,a) {
12, 
6,
15,
 4, 
8,{
4,
15,  7, 15,
 3, 14,
 0,
 9,  3, 13,{
5,
14,
 5,
11, 
1,

9,
 0,
15,
 3, 
8,
 7, 12,
 7, 
8,
 5, 
9,
 4, 12, 
6, 12,
 1, 10, 
6, 
9,
 0,
15,
 3, 14,
 0,
15,  3, 13,{
5,
15, 
5,

9,
 6, 10,
 0,
14,
 0,
13,
 1,
15,
 1,

8,{
3, 
8,
 1,  if  2, 
8,
 7, 15,
 0, 11, 
1, 12, 
1, 12, 
0, 15,
 0, 11, 
2, 13,  1, 10,
 5,  8,{
7, 1t,  6, 10,
 0, 11, 
4, 12,
 7, 10,
 1,  9,  1, 
9,
 0, 12, 
2, 11,  7, 15,
 1, 11,
 0,
 9,  2, 
8,
 4,
12, 
2, 12, 
6, 14, 
4, 14,
 3, 13,{
3, 15,
 1, 14,
 4, 15, 
6, 12,a) {
1t,  6, 11, 
t, 12, 
4,

8,{
4,

9,
 4,

9,
 5, 12, 
6, 10,
 5,
14, 
7, 14,
 t, 10,
 2, 13,{
3, 14,
 5, 
8,
 2, 13,  1, 15, 
6, 15,
 4, 
8,{
4,
15,  5, 10,
 1,
14,
 5, 12,
 4, 13,{
5,
11, 
1, 
9,
 5,  9,  3,  9,  0,
10,
 7, 10,
 7, 11, 
6, 10,
 3,  9,  0,x)",

3,
15,
 5, 
8,
 1, 
9,
 5,  8,{
4,
13,
 6, 
8,{
4,
15,  6, 10,
 6,
14,
 7, 11, 
0,

9,
 1, 12,
 0, 
8,
 6, 12, 
6, 10,
 t, 12, 
7, 1t,  7, 11,{
t, 
8,{
0,
1t,  7, 12, 
0, 15,
 4, 12, 
5,

8,{
4,
15,  5, 10,
 0,
15,  3, 15,
 1,

8,{
1,
15,
 4,
14,
 6, 15,a) {
10,

6, 14,
 0,
1t,  4, 1t,  1,  9,  1, 13,{
t, 11,{
2, 12, 
1,  8,{
t, 12, 
3,
14,
 6,  8,{
4,
15,  4,

8,{
t, 15,
 1,  9,  6, 11,
 2, 14,
 3,
1t,  7, 10,
 4, 10,
 3,  8,
 7, 11, 
2, 12, 
1, 11, 
1, 14,
 3, 
9,
 6, 
9,
 7, 1t,  5,
11,{
7, 10,
 2,  9,  3,x)",

1, 
9,
 0,
14,
 7, 12,
 7, 14,
 5, 
9,  6, 10,
 6,
14,
 6, 15, 
1, 14,
 7, 10,
 3, 12,
 0,
14,
 5, 
9,  6,  8,{
1,
12,
 0, 13,{
2, 
8,{
4,

9,
 6, 15,
 0,
14,
 4, 10,
 7, 11, 
5, 14,
 2,  8,{
4,
15,  3,  8,
 7, 1t,  1,  9,  0, 15,
 0,
14,
 5, 14,
 0,
14,a) {
15,
 4, 10,
 6,
11, 
1, 10, 
2,
14, 
3, 15,
 1, 10,
 t, 10,
 3, 
8,{
4,
12,
 3, 10,
 6, 
9,
 6, 14,
 2, 12, 
3,
11,{
4, 
9,
 6, 12,
 5, 15,
 0,
10,
 3, 
8,{
4,
14,
 1, 14,
 3, 11, 
2, 12, 
7, 11, 
2, 12, 
6, 10,
 1, 13,{
4,
11,{
4, 10,
 5,
11,
 2, 11,
 7,  if  0,

8,{
1,
11,{
4, 
8,{
4,
10,
 6,
11,{
t, 10,
 6, 10,
 6,

8,{
1,
11,{
1,
15,
 7, 15,
 6, 
9,
 1,  9,  7, 
8,
 0,
14,
 5, 12,
 3, 13,{
4,
12, 
0, 15,
 5, 12,
 1, 12, 
7, 
9,  6,  8,{
3, 15,
 0,
1t,  6, 15,
 7, 15,
 7, 1t,  2, 15,
 1, 14,  2, 15,
 0,

8,a) {
12, 
5, 13,{
5,
15,
 1, 12, 
1,
15,
 1, 14,{
6, 14,
 2, 14,
 2, 14,
 6,
11,{
6, 11, 
t, 12, 
2,
1t,  6, 15,
 3, 
9,
 5, 
8,
 2, 
8,
 5, 
9,
 1, 
9,
 4,

9,
 2,  8,{
4,
13,  1, 1t,  0,
11, 
6, 11, 
6, 
9,
 2,
11,{
t, 10,
 1, 10, 
6, 
9,
 6, 11,  7, 15,
 5,x)",

5,
12,
 0, 
9,
 5, 
8,
 5, 
9,
 0,
10,
 2, 13,  4,

8,{
5, 14,
 2,  9,
 2,
15,  4,

8,{
2,

8,{
0, 12, 
6, 12,
 0,
10,
 5,
15,  4,

9,  3, 13,{
0, 
9,
 4,
15,
 1, 14,{
1,  9,  0, 
9,
 2, 14,
 6, 12,
 0,
15, 
7, 
9,  2,  9,  0, 15,
 6, 10,
 t, 15,
 3, 13,  if  9,  1, 15,
 5, 12,
 3, 14,
 0,
15,  7, 
8,
 5, 14,
 1,
11,{
1,
1t,  6, 10,
 7, 13,
 0, 14,
 5, 10,
 7, 11, 
t, 15,
 6, 11, 
1, 12, 
2,  8,{
4,
13,  5, 10, 
2,
10,
 6,
13,  5, 1t,  4, 10,
 5,  9,  3,  8,{
4,
12,
 1, 12, 
5,
11,
 6, 14, 
3, 11, 
7, 11, 
7,  if  2, 11, 
4, 12,
 7,  8,{
3, 15,
 3,
11,{
4,
11,{
7, 10,
 1, 10, 
2,
10,
 0, 11, 
4, 12,
 0, 10,
 1,  8,
 7, 11, 
1, 10,
 1, 15,{
7, 10,
 2, 11, 
1, 
9,
 6, 14,
 2, 11, 
1, 14,
 4, 12, 
2, 13,  1, 
9,
 5,  8,
 7, 11, 
7, 10,
 7, 15,
 4, 13,{
t, 10,
 1, 11,a) {
1t,  5,  8,
 0, 15,
 3,
11,{
6, 12,
 7, 15,  3, 15,
 1,
15,
 4,
14,
 5, 1t,  6,

8,{
1,
15,
 6, 13,  5, 12, 
2, 15,  4,

9,  4,
15,  3, 14,{
6, 14,
 5,  9,  3, 12, 
6, 11,
 5, 
8,
 2, 
9,
 5, 12, 
5,
15,
 1, 13,{
3, 14,
 2,

8,{
0, 
8,{
0, 12, 
7, 15,
 5,x)",

0, 14,
 1,

8,{
2,

8,{
2, 15,  2, 
9,
 6, 12,
 0,
12, 
7, 12, 
7, 1t,  0, 15,
 6, 14,
 5,
11, 
1,
12, 
5,

8,{
5, 
8,
 1, 14,
 0,
10,
 4, 12, 
6, 
9,  6,  8,{
0, 
9,
 0, 15,
 4, 15,
 5, 13,  1, 15, 
5, 12, 
7, 10,
 6,
14,
 4,

9,
 6, 15,
 0,
15,
 7, 1t,a) {
10,

4,
13,  5, 1t,  5,
11,{
5, 12, 
5,
 9,  3,  9,  4,

8,{
t,  9,  3, 10,
 6,
11, 
1, 15,  2, 
8,{
5, 15,
 1, 13,{
2, 11, 
6,
14,
 6, 
8,{
2, 15,  3, 14,
 t, 13,
 6, 
9,
 6, 
9,
 0,
10,
 2, 10,
 7, 11, 
1, 15,  3, 
9,  3, 13,{
t, 10,
 3, 
9,
 4, 10,
 1,x)",

4, 11,{
7, 10,
 2, 14, 
4, 15,
 3, 15,{
2, 15,  7, 10,
 2, 14, 
1,

8,{
0, 15,  2, 
8,{
1, 12, 
2, 13,  1, 
8,
 7, 12,
 6,
11, 
1, 10, 
4, 11,{
2, 15,
 0,
1t,  0, 12, 
7, 11, 
5, 12, 
7, 
8,
 6, 15, 
4, 12,
 7, 10,
 6, 10,
 0, 10,
 0, 11, 
4, 12,
 7, 10,a) {
1t,  2, 14,
 2, 10,
 7, 11, 
1, 11, 
7, 11, 
7, 12, 
3,
11,{
7, 13,{
4,
11,{
6, 12,
 5, 11, 
6, 10,
 7, 13,{
4,
11,{
3, 15,
 3,
14, 
4, 15,
 3, 
8,
 5, 10,
 7, 10,
 6, 15,  3, 
9,  3, 15, 
1, 11, 
3,  9,  0,
15,
 1,
15,
 3, 15, 
4, 1t,  5,  8,
 3, 15,
 3,x)",

3,

9,
 1, 12, 
4,
14,
 0,
11,{
7, 15, 
1, 11, 
3, 14,
 0,
11,{
5, 10, 
2,
10,
 2, 
8,{
6,
14,
 7, 11, 
0,
10,

7, 14,
 7, 15,
 6, 
9,
 6,

9,
 1, 12, 
7, 
9,
 4,  8,{
7, 1t,  0, 1t,  6, 12, 
6, 
8,  1,  9,  1, 15, 
4, 12,
 0, 12, 
4,
10,
 0,
1t,  0, 12,a) {
1t,  5, 10, 
6, 
9,
 1,
1t,  6, 11, 
0,
14,
 7, 11, 
7, 14,
 5, 15,{
2, 13,{
5,
15,
 4,

9,
 2, 13,{
3, 14,
 7, 10,
 3, 10,
 3, 12,
 t, 12, 
2,

8,{
5, 15,
 3, 13,{
t, 11,{
t, 10,
 4,

9,  3, 15,
 1, 14,{
4,
11,{
6, 10,
 3, 
8,{
4,
1t,  0, 10,
 4,

8,{
5,x)",

5,

8,{
3, 1t,  4,
14,
 1, 13, 
7, 
9,
 2, 14, 
4, 14,
 4, 12, 
7, 10,
 6, 10,
 5, 12, 
2, 11,{
6, 12,
 7, 13,{
4,
11,{
2,
11,{
t, 
8,{
5, 15,
 2,
10,
 1, 
9,
 2, 12,
 0, 12, 
0, 10,
 1, 12,
 0, 
9,
 7, 10,
 0, 15, 
4,

9,  0,

8,{
1,
14, 
4, 14,
 4, 13,a) {
12, 
2, 
8,{
6,
10,  0,

8,{
5, 1t,  3, 
8,
 5, 10,
 3, 11, 
2, 15,
 0,
1t,  3, 
8,
 2, 15,
 6, 
9,
 1,  8,{
t, 14,
 1, 15, 
5, 14,
 7, 
8,{
0, 12, 
6, 15, 
5, 
8,
 5, 
9,
 4, 15, 
5, 
8,
 5, 15, 
4, 12,
 3, 
9,
 6, 12,
 3, 13,{
5, 11, 
7, 10,
 1,  8,{
t,x)",

4, 15,
 2,
11, 
2, 10,
 6,
11,{
t, 14,
 7, 15,
 0, 10,
 0, 14,
 t, 12,
 4,  8,{
7,  9,  3, 11,  0, 13,{
2, 12, 
2, 13,  5,

8,{
5, 
8,
 2, 11, 
4, 12,
 2, 10,
 7, 
8,{
6,
10,  7, 12, 
7, 11,  0, 15,  7, 
8,
 7, 15,
 0,

9,
 2, 12, 
6, 13,{
0, 
9,
 4,

9,  if  8,{
t, 12, 
5,
15,
 5, 13,  1,  8,{
7,  8,{
t, 12, 
5,

9,
 5,  9,  6,
14,
 1, 12,
 3, 15,  7, 10,
 7, 
8,
 5, 
8,
 5, 15, 
0, 13,  1, 14,
 7, 
9,  1, 14,
 7, 13,{
2, 12, 
3, 
8,
 1, 13,{
3,  8,{
4,
12,
 0,
11,{
t, 12, 
5,
11, 
5,
 9,  3, 12, 
6, 14, 
2,x)",

5,
13, 
2, 
8,{
6,
12, 
7, 10,
 5, 14,
 4,
11,{
2,
11,{
2, 13,{
2, 1t,  5, 10, 
5,
 9,  0,
10,

7, 13,{
4,
15,  2, 
9,
 1, 
9,
 5,  9,
 6, 10,
 4, 12, 
5,
12, 
4,
10,
 3, 14,
 t, 15,  1,  8,{
4, 12, 
5,

8,
 5, 14,
 7, 11, 
7, 15,
 5, 11,{
2, 13,{
1,

9,  if 10,
 0,
1t,  6, 10,
 2, 15,  3, 
8,{
1, 12, 
2, 14,
 6, 
8,{
5,
10,

7, 13,{
1, 13,{
1, 12, 
7, 
9,
 1, 
9,
 2, 12,
 5,
12, 
4,
12,
 t, 12, 
2,

9,  0,

8,{
1,
15,
 1, 10,
 7, 10,
 6, 12, 
4,
11, 
1, 14,
 2,
11,{
0, 14,
 1,

9,
 2, 12,
 2,

8,{
5, 1t,  5,  if  6, 10,
 7, 11, 
0, 
9,
 3, 
9,
 5, 11, 
0, 
8,{
0,
1t,  2, 13,{
4, 1t,  5,  9,
 4,  8,{
2,

8,{
0, 10,
 0, 14,
 6, 
9,
 6,

9,
 4, 14,
 7, 
9,
 0,
11,{
7, 10,
 7, 11, 
7, 14,
 4,
14,
 5, 15,
 4,  8,{
4,
11, 
5, 14,
 0,

8,{
1,
14, 
7, 14,
 2, 11, 
7, 1t,a) {
12,
 3, 13,{
3,
14,
 5, 15,
 6, 12,
 0,
15, 
4,
11, 
5, 
9,
 5,  9,
 2, 14, 
1,
12,
 1, 13,{
5,
15,
 4,
11, 
7, 12, 
1, 13,{
2,  8,{
1,
12,
 0, 15,
 6, 14,
 2, 14, 
t, 10,
 1, 11,  3, 11,  0, 12, 
1, 15,
 2,
11, 
1, 12, 
4,

9,
 4, 10,
 2, 13,{
6, 10,
 2,  if  2, 
8,
 4,  8,{
4,
 9,  0, 
9,
 2, 15, 
5, 
9,
 6, 11,  7, 14,
 0,

9,
 2, 12, 
2,

8,{
0, 10,
 1,

9,
 7, 
8,
 2, 
9,
 1, 11,{
2,
11,{
2, 
8,  1,  9,  1, 11,{
7, 13,{
6,
11, 
1, 11,
 0,

9,
 2, 1t,  4,
14,
 1, 15,  2, 
8,{
7, 15,
 0, 13,
 6, 
9,
 4, 13,a) {
13,  5, 1t,  1, 14,
 0,
12, 
6, 
9,  6, 12,
 0, 13,{
0,
11,{
t, 13,{
6,
11, 
7, 12, 
5, 14,
 6, 14,
 5,
15,{
t, 13,{
6,
14,
 7, 15,
 6, 15,
 5, 13,  4,
14,
 5, 
8,
 2, 14, 
t, 14,
 6, 14,
 5,
10,
 6, 10,
 2, 
9,
 5,
15,
 5, 11, 
1, 
8,{
5, 1t,  3, 11,{
2,  if  2, 
8,
 6,  8,{
0, 
9,
 1, 15,
 0, 11, 
4, 15,  7, 
8,
 4,  8,{
1, 13, 
7, 11,{
1,
1t,  5, 15,
 1, 15,  2, 
9,
 0,
1t,  5, 12,
 t, 12, 
2,

8,{
1, 10,
 1,
1t,  5, 15,
 3, 
9,  3, 
9,
 2, 12,
 5,
14,
 6, 13,{
1,

9,
 6, 
9,
 1,  8,{
4, 15,  7, 10,
 7, 15,  if 14,
 5, 14, 
t, 12, 
4,
10,
 7, 12,
 7, 
8,
 2, 12,
 1, 13,{
2, 11, 
4, 1t,  3, 
8,{
5, 
8,
 1, 10,
 7, 12,
 6, 
9,
 5, 
8,
 0,

8,{
7, 14,
 5, 13,
 6, 
8,
 4,  8,{
2, 12, 
6, 13,{
5,

8,{
7,  8,{
t, 10,
 3, 13,  4,
12,
 1, 13,{
4,
11, 
1, 14,
 3, 
8,{
1,  if  2, 13,  6, 10,
 0, 
9,  1, 15,
 0, 12, 
4,
11, 
2,

9,  0,

9,
 0,
1t,  1,  8,{
0,
11,{
5, 
9,  6, 13,{
2, 15,
 2,
12, 
7, 12, 
6, 15, 
2, 14, 
1,
1t,  1, 14,
 4,
11,{
2,
14,
 1,

9,
 0,
15,
 1,
12,
 5,
14,
 6, 13,{
2, 15,  3, 
9,  1, 15,
 7,  8,{
1, 14,  if 11,{
7, 13,{
t, 15,  6, 
8,
 4,  8,{
4,
14,
 2,
14,
 6, 13,{
6,
11, 
4, 14,
 4, 15, 
4, 14,
 t, 10,
 2, 10,
 5, 
9,  6, 
9,  3, 
9,
 1, 11,
 6, 
9,
 4,  8,{
4, 15,  0,  8,{
4, 13,{
4,

9,
 4,

9,
 5,  9,  3, 10,
 2, 
9,
 5,
12,
 6, 
8,{
4,
12,
 0,
11,{
4,x)",

4, 10,{
4, 13,{
1, 12, 
7, 
8,{
0,
1t,  4, 12,
 2, 13,  1, 14,
 7, 15,  3,  8,
 7, 12,  3, 10,
 4,

9,
 4, 11,
 7, 
8,
 2, 11, 
2, 10,
 0, 12, 
1, 14,
 6, 14,
 7, 1t,  7, 11,{
t, 10,
 0, 10,
 4,

9,  3, 1t,  0, 1t,  7, 
8,
 7, 
9,
 7, 11,{
2, 
8,  1, 14,a) {
15,
 0,
11,{
1,

9,
 6, 15,{
t, 10,
 7, 
9,
 1,

9,
 7, 10,
 7, 10,
 1,
12,
 5,

8,{
1,
15,
 7, 13,{
t, 12,
 2, 13,  2, 14,
 7, 14,
 5,
10,
 4,  8,{
4,
11, 
1, 10,
 t, 14,
 0, 14,
 6, 14,
 5,
13,{
2,  8,{
7, 10,
 7, 13,  2, 14,
 2, 13,  2, 14,
 5, 11, 
6,x)",

7, 11, 
5, 13,  1, 11,
 7, 
8,
 5, 14,
 4,
13,  1, 14,
 5,
10,
 2, 15,  4,
13,  7, 11, 
7, 10,
 1, 
8,{
5, 
9,
 4, 12, 
7, 10,
 1, 13,  7, 13,  7, 11, 
0, 14,
 5, 14, 
2, 14,
 4,
12,  4,
13,  7, 1t,  7, 
8,
 2, 14,
 2, 13,  5, 
9,
 5,  9,
 2, 
8,
 1, 10,a) {
12,
 0, 
8,
 2, 13,  4,
12,
 1, 11, 
1, 10,
 1, 10,
 4, 12,
 2, 11,{
5, 
8,{
1,
15,
 t, 14,
 1, 13,  4,
14,
 2, 
9,
 2, 12,
 2, 
8,
 4,  8,{
2, 12, 
3, 10,
 6,
11,{
0,
11,{
7, 10,
 1,

9,
 2, 10,
 0,
1t,  1,
11,{
7, 10,
 6, 13,{
1,
12,
 1, 12, 
6, 14,
 7,  if  2, 14,
 4, 15, 
7, 14,
 5,
 8,{
4, 13,{
2, 10,{
4, 13,{
0,
1t,  1,
11,{
1, 12, 
7, 12, 
6, 13,{
4, 13,{
4, 13,{
2, 12,
 2, 13,{
1, 13,{
7, 10,
 2, 11, 
2, 10,{
7, 15,
 7, 11, 
5, 13,  2, 
8,
 2, 14,
 4,  9,
 2, 14, 
0,

8,{
1,
 8,{
7, 10,
 5, 15,
 6, 14,  if 11,{
7, 10,
 2, 11, 
1, 13,{
0,
11, 
1, 15,
 7,  8,{
1, 
9,
 4, 13,
 4,  8,{
4,
 8,{
t, 10,
 0,

9,
 0,

9,  2,  9,  7, 
9,
 6, 10,
 7, 13,{
1, 13,{
7, 14,
 6, 11,{
t, 12,
 2, 
8,
 2, 12,
 5,
11, 
5, 12,
 2, 10,
 5, 14,
 4,
12,  4,
13,  2, 
9,
 1, 10,
 0,  if  2, 12,
 0, 13,{
7, 13,{
2, 12, 
4,  8,{
1, 12,  4,
13,  6,
11, 
7, 13,
 7, 13,{
1, 
9,
 7, 10,
 2, 10,
 1,

9,
 2, 10,
 1, 11,
 6, 
9,
 4, 13,{
2, 10,{
0, 10,
 2, 14,
 0, 13,{
7, 10,
 7, 10,
 0, 12,
 0, 
9,
 0,
1t,  2, 13,{
1, 
9,
 0,
15,
 2, 14,
 2, 13,  if 11,{
7,  8,{
4, 10,
 2, 10,
 7, 12, 
1, 11,
 7, 
8,
 2, 13,{
1, 10,{
0, 10,
 2, 13,{
6,
14,
 0, 14,
 7, 13,{
6,
14,
 5, 13,  4,
15,
 1, 10,
 2, 13,
 7, 13,{
7, 
9,
 4,  9,  6, 13,{
3, 13,{
3,
 8,{
4, 13,{
4,
10,
 6, 10,
 5, 12, 
4,
10,
 7, 11,
 6, 
9,
 6,x)",

4, 14,
 6, 11,{
7, 13,{
6,
10,
 4,  8,{
4,
11, 
6, 
8,{
5,
13,{
7, 14,
 7, 14,
 1, 
9,
 0,
12,
 1, 
9,
 1, 12,  4,
14,
 7, 10,{
4, 13,{
7, 13,  7, 11, 
4,
10,
 1, 11,{
7, 13,{
4,
12,
 1, 10,
 4, 12,
 2, 
8,
 2, 12,
 2, 10,
 2, 12,
 1, 12,
 4, 12,
 2, 12,a) {

8,
 2, 13,{
2, 
8,
 1, 13,{
1,
12,
 1, 12, 
2, 12,
 2, 11,{
1,

9,
 2, 11,{
t, 12, 
4,

8,{
4,
12,
 4,
10,
 6, 10,
 1, 13,{
2, 11, 
2, 10,
 1, 12,
 0, 14, 
2, 14,
 4,
 9,
 2, 
8,
 1, 13,
 4,  8,{
0, 12, 
4,
11, 
6, 12, 
6, 11,{
7, 10,
 7, 11, 
2, 10,
 72767
/*};

sta on const 8ntepyk ei_matrsx_halftone8[4 + 8*8]i=(ta) {
8,
8, 64, 3,  if 60,{53,
42, 26, 27, 4t, 54, 61,x)",
52, 41,i_t, 1t, 14,
28, 44, 55,x)",
40,{24,
12,
 5,

6, 15,{29, 45,x)",
39,
23,
 4,  0,
 1,

7, 16, t0,x)",
38,
22, 11,{
t, 
2, 
8,
17, 31,x)",
51, t7,{21, 10,
 9,
18, 32,
46,x)",
59,
50,
36, 20,
19, 3t, 47, 56,x)",
63,
58,
49, 35,
34,
48, 57,{62276 N
 **/  sta on const 8ntepyk ei_matrsx_diagonal45_8[4 + 8*8]i=(ta) {
8,
8, 64, 2,a) {
16, 32,
48, 56, 40,{24,
 8,{
0,x)",
36,
52, 60,{44, 28, 12, 
4,
20,x)",
49, 57,{41,i_t, 
9,
 1, 17, 3t,x)",
61, 45,
29, 13,  5, 21, t7,{53,  if 42, 26, 10,
 2, 18,
34,
50,
58,a) {
30, 14,
 6, 22, 38,
54, 62,
46,x)",
11,{
t, 19, 35,
51, 59,
4t, 27,x)",

7, 23,
39,
55,
63,
47, 31, 152767

&& (def strucdohalftone_pP].psefo++d) {
    xnf++)
 
  y;s */
doua_ts  , afer;s */
doua_tsamodo;
}ohalftone_pP].psefo67
};

stainlineohalftone_pP].psefo*ohalftone_pP].p_olk ripa w,a{
  h)++d) {
    x, y, k   if halftone_pP].psefo*ohpl[j] = Gif_NewArhalftone_pP].psefo, w *ohIe pi;
    fymenk [i]  y !e hig++y nt);
t);
    fxo i]  x !e wi2++x,= 2k ++z) {
        hp k..xr (xne            hp k..ymenyne            hp k..  , aferren-1[2])))))))}ff       reihp 0}di    stainlineotic vhalftone_pP].p_combinerhalftone_pP].psefo*ohpax)",
                           +++++++++++doua_tscx,=doua_tscy ++d) {
doua_ts  =
hhp->x -scxridthhp->x -scxri+thhp->y -scyridthhp->y -scyrnf++)
 fthhp->  , aferr<m0 ||er < hp->  , afer ++z) {
    hp->  , aferr= d;z) {
    hp->amodo = d af2hhp->y -scy, hp->x -scxr =+i)
  }di    stainlineo{
  halftone_pP].p_comrans( on cotic * va,
 on cotic * vb ++z) {
 on cohalftone_pP].psefo*o_dat( on cohalftone_pP].psefo*) va;z) {
 on cohalftone_pP].psefo*obdat( on cohalftone_pP].psefo*) vbnf++)
 fthfabs(a->  , aferr- b->  , afer +> 0.01 nt);
t);
    reia->  , aferr<mb->  , afer ?n-1 :(1 0) {
    i++)
        reia->amodo <mb->amodo ?n-1 :(1 0}di    stanst 8nt* halftone_pP].p_oltrsxrhalftone_pP].psefo*ohpax)",
                           +++++++ipa w,a{
  h,a{
  n )++d) {
    ;data;
nst 8nt16ml[j] = Gif_NewAr/ay(8nt,a4 + w *ohIe pi;
m[le e wi pi;
m[1e e hi pi;
m[3]i=(ncnf++)
 fthw *oh+> 255 ++z) {
    doua_tsss[1bl5. /thw *ohount);
t);
m[2]s[1bl5;nt);
t);
    for (i = 0; iw *oh;= 2; ++i)
        m[4 + hp i..x + hp i..y*w]s[1] = (ini *osIe pi;
    } else {
  ;
m[2]s[1w *oh;nt);
t);
    for (i = 0; iw *oh;= 2; ++i)
        m[4 + hp i..x + hp i..y*w]s[1i =+i)
    ;
;
  Gif_DeleteArhpIe pi;
    reim 0}di    stanst 8nt* olk _halftone_matrsx_squans(ipa w,a{
  h,a{
  n )++d) {
halftone_pP].psefo*ohpl[jhalftone_pP].p_olk rw,ahount);
    ;data;
    for (i = 0; iw *oh;= 2; ++i)
    halftone_pP].p_combiner&hp i.,thw-1)/2.0, (h-1)/2.0ount);
q /* (hpaiw *ohd(ta, siz*hpI, halftone_pP].p_comransIe pi;
    reihalftone_pP].p_oltrsxrhpaiw,ohd(n ) 0}di    stanst 8nt* olk _halftone_matrsx_trsamo reg(ipa w,a{
  h,a{
  n )++d) {
halftone_pP].psefo*ohpl[jhalftone_pP].p_olk rw,ahount);
    ;data;
    for (i = 0; iw *oh;= 2; ++z) {
    halftone_pP].p_combiner&hp i.,thw-1)/2.0, (h-1)/2.0ount);
    halftone_pP].p_combiner&hp i.,t-0.5,t-0.5ount);
    halftone_pP].p_combiner&hp i.,tw-0.5,t-0.5ount);
    halftone_pP].p_combiner&hp i.,t-0.5,th-0.5ount);
    halftone_pP].p_combiner&hp i.,tw-0.5,th-0.5ount);
}nt);
q /* (hpaiw *ohd(ta, siz*hpI, halftone_pP].p_comransIe pi;
    reihalftone_pP].p_oltrsxrhpaiw,ohd(n ) 0}di     et_pyk ei_&& ((tt_Outpuf_OptD od,
 on cochar  nime)++d) {
    ranm[4],anpanmi=(] =+i)
 on cochar  comm_datstrchr(nime, ','Ie pi;
char bufou56.;(d) {
/*rsepanathaargumentsxata f  pe otnime els *

    comm_d   (ta, _ (incomm_d- nime)+<(ta, sizbuf) ++z) {
        py(buf, nime, comm_d- nime) 0 */
    bufocomm_d- nime]o i] =+i)
    nime = bufunt);
}nt);
    fnpanmi=(] =+i)
 +i)
 omm_d   * omm_d   isdigit(h = (unsi
char)
 omm_[1e_gfi);





++npanm ++i)
    panm[npanm]datstrtol(& omm_[1e, (char *) & omm_, 10); s */
   pansef  pe otnime els *

    md opyk ei_&& (t=pepyk ei_ordmequinewla        ;
  Gif_DeleteArod opyk ei_ous_)re    md opyk ei_&& (t=epyk ei_none; s */
lse strcmp(nime, "none")i==m0 ||estrcmp(nime, "pos_era, ") =2]  ++i)
    /*rokhin = 0;
    else strcmp(nime, "default") =2]  ++i)
    md opyk ei_&& (t=epyk ei_default = 0;
    else strcmp(nime, "floyd-steinberg") =2] ++i)
         ||estrcmp(nime, "fs") =2]  ++i)
    md opyk ei_&& (t=epyk ei_floydasteinberg = 0;
    else strcmp(nime, "o3")i==m0 ||estrcmp(nime, "o3x3") =2] ++i)
         ||e strcmp(nime, "o") =2] o   npanmi>= 1o   panm[0eye[13) ++z) {
    md opyk ei_&& (t=epyk ei_ordmequ;z) {
    md opyk ei_ser_datpyk ei_matrsx_o3x3e pi;
    } else strcmp(nime, "o4")i==m0 ||estrcmp(nime, "o4x4") =2] ++i)
           ||e strcmp(nime, "o") =2] o   npanmi>= 1o   panm[0eye[14) ++z) {
    md opyk ei_&& (t=epyk ei_ordmequ;z) {
    md opyk ei_ser_datpyk ei_matrsx_o4x4e pi;
    } else strcmp(nime, "o8")i==m0 ||estrcmp(nime, "o8x8") =2] ++i)
           ||e strcmp(nime, "o") =2] o   npanmi>= 1o   panm[0eye[18) ++z) {
    md opyk ei_&& (t=epyk ei_ordmequ;z) {
    md opyk ei_ser_datpyk ei_matrsx_o8x8e pi;
    } else strcmp(nime, "ro64")i==m0 ||estrcmp(nime, "ro64x64") =2] ++i)
           ||estrcmp(nime, "o") =2] o||estrcmp(nime, "ordmequ") =2]  ++z) {
    md opyk ei_&& (t=epyk ei_ordmequ;z) {
    md opyk ei_ser_datpyk ei_matrsx_ro64x64e pi;
    } else strcmp(nime, "diag45") =2] o||estrcmp(nime, "diagonal") =2]  ++z) {
    md opyk ei_&& (t=epyk ei_ordmequ;z) {
    md opyk ei_ser_datpyk ei_matrsx_diagonal45_8e pi;
    } else strcmp(nime, "halftone") =2] o||estrcmp(nime, "half") =2] ++i)
           ||estrcmp(nime, "trshalftone") =2] ++i)
           ||estrcmp(nime, "trshalf") =2]  ++z) {
         a,  =
npanmi>= 1o   panm[0ey> x7? panm[0ey: 6;z) {
        ap->r (npanmi>= 2o   panm[1ey> 17? panm[1ey: 2;z) {
    md opyk ei_&& (t=epyk ei_ordmequinew;z) {
    md opyk ei_ser_datolk _halftone_matrsx_trsamo reg( a, ,1] = (in a,  *rsq* (3ri+t0.5o, ap->)unt);
    } else strcmp(nime, "sqhalftone") =2] o||estrcmp(nime, "sqhalf") =2] ++i)
           ||estrcmp(nime, "squanshalftone") =2]  ++z) {
         a,  =
npanmi>= 1o   panm[0ey> x7? panm[0ey: 6;z) {
        ap->r (npanmi>= 2o   panm[1ey> 17? panm[1ey: 2;z) {
    md opyk ei_&& (t=epyk ei_ordmequinew;z) {
    md opyk ei_ser_datolk _halftone_matrsx_squans( a, ,1 a, ,1ap->)unt);
    } i++)
        rei-1; s */
lse od opyk ei_&& (t=pepyk ei_ordmequ 7);




   npanmi>= 2o   panm[1ey> 17   panm[1ey; imd opyk ei_ser_[3] ++z) {
         a,  =
md opyk ei_ser_[0ey*
md opyk ei_ser_[1.> 7);




nst 8nt* ddl[j] = Gif_NewAr/ay(8nt,a4 +  a, ount);
t);
m   py(dd,
md opyk ei_ser_,a4 +  a, ount);
t);
dd[3]i=(panm[1e;z) {
    md opyk ei_ser_datpu;z) {
    md opyk ei_&& (t=epyk ei_ordmequinew;z) {
}ff       rei] =};    